export class Cargo {
    id: number;
    nome: string;
    descricao: string;
    salario: number;
    cbo1994: string;
    cbo2002: string;
}
