import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';

import { environment } from './../../../environments/environment';
import { TipoColaborador } from '../../classes/cadastros/tipo-colaborador';

@Injectable({
  providedIn: 'root'
})
export class TipoColaboradorService {

  private url = environment.urlBaseServidor + 'tipoColaborador/';

  constructor(private http: HttpClient) {  }

  getTipoColaboradors(): Observable<TipoColaborador[]> {
    return this.http.get<TipoColaborador[]>(this.url);
  }

  getListaTipoColaborador(nome: string): Observable<TipoColaborador[]> {
    return this.http.get<TipoColaborador[]>(this.url + 'lista/' + nome);
  }

  getTipoColaborador(id: number): Observable<TipoColaborador> {
    return this.http.get<TipoColaborador>(this.url + id);
  }

  salvar(tipoColaborador: TipoColaborador): Observable<TipoColaborador> {
    return this.http.post<TipoColaborador>(this.url, tipoColaborador, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
