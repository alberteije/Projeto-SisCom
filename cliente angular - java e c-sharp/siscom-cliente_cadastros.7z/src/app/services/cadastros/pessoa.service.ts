import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';
import { environment } from './../../../environments/environment';

import { Pessoa } from '../../classes/cadastros/pessoa';

@Injectable({
  providedIn: 'root'
})
export class PessoaService {

  private url = environment.urlBaseServidor + 'pessoa/';

  constructor(private http: HttpClient) {  }

  getPessoas(): Observable<Pessoa[]> {
    return this.http.get<Pessoa[]>(this.url);
  }

  getListaPessoa(nome: string): Observable<Pessoa[]> {
    return this.http.get<Pessoa[]>(this.url + 'lista/' + nome);
  }

  getPessoa(id: number): Observable<Pessoa> {
    return this.http.get<Pessoa>(this.url + id);
  }

  salvar(Pessoa: Pessoa): Observable<Pessoa> {
    return this.http.post<Pessoa>(this.url, Pessoa, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
