import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';
import { environment } from './../../../environments/environment';

import { Cargo } from '../../classes/cadastros/cargo';

@Injectable({
  providedIn: 'root'
})
export class CargoService {

  private url = environment.urlBaseServidor + 'cargo/';

  constructor(private http: HttpClient) {  }

  getCargos(): Observable<Cargo[]> {
    return this.http.get<Cargo[]>(this.url);
  }

  getListaCargo(nome: string): Observable<Cargo[]> {
    return this.http.get<Cargo[]>(this.url + 'lista/' + nome);
  }

  getCargo(id: number): Observable<Cargo> {
    return this.http.get<Cargo>(this.url + id);
  }

  salvar(cargo: Cargo): Observable<Cargo> {
    return this.http.post<Cargo>(this.url, cargo, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }
}
