import { Component, OnInit } from '@angular/core';

import { ConfirmationService } from 'primeng/api';

import { VariaveisGlobais } from './../../../classes/variaveis-globais';
import { Colaborador } from './../../../classes/cadastros/colaborador';
import { ColaboradorService } from './../../../services/cadastros/colaborador.service';
import { ObjectUtils } from '../../../../../node_modules/primeng/components/utils/objectutils';

@Component({
  selector: 'app-colaborador',
  templateUrl: './colaborador.component.html',
  styleUrls: ['./colaborador.component.css']
})
export class ColaboradorComponent implements OnInit {

  colaboradores: Colaborador[];
  cols: any[];
  colaboradorSelecionado: Colaborador;
  botoesDesabilitados: boolean = true;

  constructor(private colaboradorService: ColaboradorService,
    private confirmationService: ConfirmationService,
    private global: VariaveisGlobais,
    private objectUtils: ObjectUtils) { }

  ngOnInit() {
    this.global.tituloJanela = "Lista de Colaboradores";
    this.carregaDados();

    this.cols = [
      { field: 'pessoa.nome', header: 'Nome' },
      { field: 'cargo.nome', header: 'Cargo' },
      { field: 'setor.nome', header: 'Setor' },
      { field: 'matricula', header: 'Matrícula' }
    ];
  }

  resolveFieldData(data, field) {
    return this.objectUtils.resolveFieldData(data, field);
  }

  private carregaDados() {
    this.colaboradorService.getColaboradores().subscribe(
      lista => {
        this.colaboradores = lista;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  onRowSelect(event) {
    this.botoesDesabilitados = false;
  }

  onRowUnselect(event) {
    this.botoesDesabilitados = true;
  }

  getIdCargo() {
    return this.colaboradorSelecionado == null ? null : this.colaboradorSelecionado.id;
  }

  excluir() {
    this.confirmationService.confirm({
      message: 'Excluir o registro selecionado?',
      header: 'Confirmação',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.colaboradorService.excluir(this.colaboradorSelecionado.id).subscribe(
          _ => {
            this.carregaDados();
            this.botoesDesabilitados = true;
            this.global.mostraMensagem(this.global.info, "Confirmação", 'Registro excluído com sucesso');
          },
          error => {
            this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
          }
        );
      },
      reject: () => {
        //this.msgs = [{ severity: 'info', summary: 'Rejected', detail: 'You have rejected' }];
      }
    });
  }
}
