import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { Location } from '../../../../../../node_modules/@angular/common';
import { FormGroup, FormControl, Validators, FormBuilder } from '../../../../../../node_modules/@angular/forms';
import { environment } from './../../../../../environments/environment';

import { Colaborador } from './../../../../classes/cadastros/colaborador';
import { VariaveisGlobais } from './../../../../classes/variaveis-globais';
import { ColaboradorService } from './../../../../services/cadastros/colaborador.service';
import { Pessoa } from '../../../../classes/cadastros/pessoa';
import { PessoaService } from './../../../../services/cadastros/pessoa.service';
import { TipoColaboradorService } from './../../../../services/cadastros/tipo-colaborador.service';
import { CargoService } from './../../../../services/cadastros/cargo.service';
import { SetorService } from './../../../../services/cadastros/setor.service';
import { TipoColaborador } from '../../../../classes/cadastros/tipo-colaborador';
import { Setor } from '../../../../classes/cadastros/setor';
import { Cargo } from './../../../../classes/cadastros/cargo';
import { Usuario } from './../../../../classes/cadastros/usuario';

@Component({
  selector: 'app-colaborador-detalhe',
  templateUrl: './colaborador-detalhe.component.html',
  styleUrls: ['./colaborador-detalhe.component.css']
})
export class ColaboradorDetalheComponent implements OnInit {

  colaborador: Colaborador;
  filtroPessoa: Pessoa[];
  filtroCargo: Cargo[];
  filtroSetor: Setor[];
  filtroTipoColaborador: TipoColaborador[];
  urlUpload = environment.urlBaseServidor + 'colaborador/upload/';
  urlFoto: string;
  userform: FormGroup;

  constructor(private colaboradorService: ColaboradorService,
    private pessoaService: PessoaService,
    private setorService: SetorService,
    private cargoService: CargoService,
    private tipoColaboradorService: TipoColaboradorService,
    private route: ActivatedRoute,
    private location: Location,
    private router: Router,
    private global: VariaveisGlobais,
    private fb: FormBuilder) { }

  ngOnInit() {
    this.userform = this.fb.group({
      'id': new FormControl(''),
      'pessoa': new FormControl('', Validators.required),
      'setor': new FormControl('', Validators.required),
      'cargo': new FormControl('', Validators.required),
      'tipoColaborador': new FormControl('', Validators.required)
    });

    this.global.tituloJanela = "Detalhe Colaborador";
    this.colaborador = new Colaborador();

    if (this.router.url !== '/colaborador/novo') {
      let id = this.route.snapshot.paramMap.get('id');
      this.colaboradorService.getColaborador(parseInt(id, 0)).subscribe(
        obj => {
          this.colaborador = obj;
          this.urlUpload = this.urlUpload + this.colaborador.id;

          this.atualizaUrlFoto();
          this.userform.patchValue(this.colaborador);
        },
        error => {
          this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
        }
      );
    }
  }

  retornar() {
    this.location.back();
  }

  salvar() {
    this.colaboradorService.salvar(this.colaborador).subscribe(
      obj => {
        this.colaborador = obj;
        this.global.mostraMensagem(this.global.info, "Confirmação", 'Registro salvo com sucesso');
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  buscaPessoa(event) {
    this.pessoaService.getListaPessoa(event.query).subscribe(
      obj => {
        this.filtroPessoa = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  buscaSetor(event) {
    this.setorService.getListaSetor(event.query).subscribe(
      obj => {
        this.filtroSetor = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  buscaCargo(event) {
    this.cargoService.getListaCargo(event.query).subscribe(
      obj => {
        this.filtroCargo = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  buscaTipoColaborador(event) {
    this.tipoColaboradorService.getListaTipoColaborador(event.query).subscribe(
      obj => {
        this.filtroTipoColaborador = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  erroUpload(event) {
    const mensagem = JSON.parse(event.xhr.response).message;
    this.global.mostraMensagem(this.global.error, "Ocorreu um erro", mensagem);
  }

  onBeforeSend(event) {
    let usuario: Usuario = JSON.parse(localStorage.getItem('usuarioSessao'));
    event.xhr.setRequestHeader('Authorization', usuario.token);
  }

  onUpload(event) {
    this.global.mostraMensagem(this.global.info, "Confirmação", 'Upload realizado com sucesso');
    this.atualizaUrlFoto();
  }

  atualizaUrlFoto() {
    this.urlFoto = environment.urlBaseServidor.substring(0, environment.urlBaseServidor.length - 1);
    this.urlFoto = this.urlFoto + this.colaborador.foto34 + '?t=' + new Date().getTime();
  }

  onSubmit(value) {
    this.colaborador = value as Colaborador;
    this.salvar();
  }
}
