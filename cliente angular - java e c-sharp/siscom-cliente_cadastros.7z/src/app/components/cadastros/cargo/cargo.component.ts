import { Component, OnInit } from '@angular/core';
import { Cargo } from '../../../classes/cadastros/cargo';
import { CargoService } from '../../../services/cadastros/cargo.service';
import { ConfirmationService } from 'primeng/api';
import { VariaveisGlobais } from '../../../classes/variaveis-globais';

@Component({
  selector: 'app-cargo',
  templateUrl: './cargo.component.html',
  styleUrls: ['./cargo.component.css']
})
export class CargoComponent implements OnInit {

  cargos: Cargo[];
  cols: any[];
  cargoSelecionado: Cargo;
  botoesDesabilitados: boolean = true;

  constructor(private cargoService: CargoService,
    private confirmationService: ConfirmationService,
    private global: VariaveisGlobais) { }

  ngOnInit() {
    this.global.tituloJanela = "Lista de Cargos";
    this.carregaDados();

    this.cols = [
      { field: 'nome', header: 'Nome' },
      { field: 'descricao', header: 'Descrição' },
      { field: 'salario', header: 'Salário' },
      { field: 'cbo1994', header: 'CBO 1994' },
      { field: 'cbo2002', header: 'CBO 2002' }
    ];
  }

  private carregaDados() {
    this.cargoService.getCargos().subscribe(
      lista => {
        this.cargos = lista;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  onRowSelect(event) {
    this.botoesDesabilitados = false;
  }

  onRowUnselect(event) {
    this.botoesDesabilitados = true;
  }

  getIdCargo() {
    return this.cargoSelecionado == null ? null : this.cargoSelecionado.id;
  }

  excluir() {
    this.confirmationService.confirm({
      message: 'Excluir o registro selecionado?',
      header: 'Confirmação',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.cargoService.excluir(this.cargoSelecionado.id).subscribe(
          _ => {
            this.carregaDados();
            this.botoesDesabilitados = true;
            this.global.mostraMensagem(this.global.info, "Confirmação", 'Registro excluído com sucesso');
          },
          error => {
            this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
          }
        );
      },
      reject: () => {
        //this.msgs = [{ severity: 'info', summary: 'Rejected', detail: 'You have rejected' }];
      }
    });
  }
}
