import { Component, OnInit } from '@angular/core';
import { Cargo } from '../../../../classes/cadastros/cargo';
import { CargoService } from '../../../../services/cadastros/cargo.service';
import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { Location } from '../../../../../../node_modules/@angular/common';
import { VariaveisGlobais } from '../../../../classes/variaveis-globais';

@Component({
  selector: 'app-cargo-detalhe',
  templateUrl: './cargo-detalhe.component.html',
  styleUrls: ['./cargo-detalhe.component.css']
})
export class CargoDetalheComponent implements OnInit {

  cargo: Cargo;

  constructor(private cargoService: CargoService,
    private route: ActivatedRoute,
    private location: Location,
    private router: Router,
    private global: VariaveisGlobais) { }

  ngOnInit() {
    this.global.tituloJanela = "Detalhe Cargo";
    this.cargo = new Cargo();
    if (this.router.url == '/cargo/novo') {
      
    } else {
      let id = this.route.snapshot.paramMap.get('id');
      this.cargoService.getCargo(parseInt(id, 0)).subscribe(
        obj => {
          this.cargo = obj;
        },
        error => {
          this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
        }
      );
    }
  }

  retornar() {
    this.location.back();
  }

  salvar() {
    this.cargoService.salvar(this.cargo).subscribe(
      obj => {
        this.cargo = obj;
        this.global.mostraMensagem(this.global.info, "Confirmação", 'Registro alterado com sucesso');
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }
}
