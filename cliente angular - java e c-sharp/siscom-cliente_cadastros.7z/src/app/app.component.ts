import { Component } from '@angular/core';
import { VariaveisGlobais } from './classes/variaveis-globais';
import { LoginService } from './services/login.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(private global: VariaveisGlobais,
  private loginService: LoginService) { }

  ngOnInit() {
    this.global.tituloJanela = 'T2Ti.com - SisCom';
  }

}
