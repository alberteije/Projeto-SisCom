import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from './components/login/login.component';
import { CargoComponent } from './components/cadastros/cargo/cargo.component';
import { CargoDetalheComponent } from './components/cadastros/cargo/cargo-detalhe/cargo-detalhe.component';
import { ColaboradorDetalheComponent } from './components/cadastros/colaborador/colaborador-detalhe/colaborador-detalhe.component';
import { ColaboradorComponent } from './components/cadastros/colaborador/colaborador.component';
import { NaoEncontradoComponent } from './components/nao-encontrado/nao-encontrado.component';
import { HomeComponent } from './components/home/home.component';
import { AuthGuardService } from './auth-guard.service';

const routes: Routes = [
  {
    path: '', canActivate: [AuthGuardService],
    children: [
      { path: '', component: HomeComponent },
      { path: 'cargo', component: CargoComponent },
      { path: 'cargo/novo', component: CargoDetalheComponent },
      { path: 'cargo/:id', component: CargoDetalheComponent },
      { path: 'colaborador', component: ColaboradorComponent },
      { path: 'colaborador/novo', component: ColaboradorDetalheComponent },
      { path: 'colaborador/:id', component: ColaboradorDetalheComponent },
      { path: 'nao-encontrado', component: NaoEncontradoComponent }
    ]
  },
  { path: 'login', component: LoginComponent }
];

@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forRoot(routes)]
})
export class AppRoutingModule { }
