import { HttpHeaders } from "../../node_modules/@angular/common/http";

export const environment = {
  production: true,
  
  urlBaseServidor: '/',

  httpOptions: {
      headers: new HttpHeaders({ 'Content-type': 'application/json' })
  }

};
