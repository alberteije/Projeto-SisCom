import { TipoNotaFiscal } from './../../classes/vendas/tipo-nota-fiscal';
import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class TipoNotaFiscalService {

  private url = environment.urlBaseServidor + 'vendas/tipo-nota-fiscal/';

  constructor(private http: HttpClient) {  }

  getListaTipoNotaFiscal(nome?: String): Observable<TipoNotaFiscal[]> {
    if (nome == null) {
      return this.http.get<TipoNotaFiscal[]>(this.url);
    } else {
      return this.http.get<TipoNotaFiscal[]>(this.url + 'lista/' + nome);
    }
  }

  getTipoNotaFiscal(id: number): Observable<TipoNotaFiscal> {
    return this.http.get<TipoNotaFiscal>(this.url + id);
  }

  salvar(tipoNotaFiscal: TipoNotaFiscal): Observable<TipoNotaFiscal> {
    return this.http.post<TipoNotaFiscal>(this.url, tipoNotaFiscal, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
