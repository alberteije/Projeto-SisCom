import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';

import { VendaCondicoesPagamento } from './../../classes/vendas/venda-condicoes-pagamento';

@Injectable({
  providedIn: 'root'
})
export class VendaCondicoesPagamentoService {

  private url = environment.urlBaseServidor + 'vendas/condicoes-pagamento/';

  constructor(private http: HttpClient) {  }

  getListaVendaCondicoesPagamento(nome?: String): Observable<VendaCondicoesPagamento[]> {
    if (nome == null) {
      return this.http.get<VendaCondicoesPagamento[]>(this.url);
    } else {
      return this.http.get<VendaCondicoesPagamento[]>(this.url + 'lista/' + nome);
    }
  }

  getVendaCondicoesPagamento(id: number): Observable<VendaCondicoesPagamento> {
    return this.http.get<VendaCondicoesPagamento>(this.url + id);
  }

  salvar(vendaCondicoesPagamento: VendaCondicoesPagamento): Observable<VendaCondicoesPagamento> {
    return this.http.post<VendaCondicoesPagamento>(this.url, vendaCondicoesPagamento, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
