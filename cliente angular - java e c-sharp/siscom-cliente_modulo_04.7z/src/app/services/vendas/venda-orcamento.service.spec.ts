import { TestBed, inject } from '@angular/core/testing';

import { VendaOrcamentoService } from './venda-orcamento.service';

describe('VendaOrcamentoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [VendaOrcamentoService]
    });
  });

  it('should be created', inject([VendaOrcamentoService], (service: VendaOrcamentoService) => {
    expect(service).toBeTruthy();
  }));
});
