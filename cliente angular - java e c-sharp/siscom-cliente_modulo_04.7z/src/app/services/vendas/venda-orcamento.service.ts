import { VendaOrcamentoCabecalho } from './../../classes/vendas/venda-orcamento-cabecalho';
import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class VendaOrcamentoService {

  private url = environment.urlBaseServidor + 'vendas/orcamento/';

  constructor(private http: HttpClient) {  }

  getListaVendaOrcamentoCabecalho(codigo?: String): Observable<VendaOrcamentoCabecalho[]> {
    if (codigo == null) {
      return this.http.get<VendaOrcamentoCabecalho[]>(this.url);
    } else {
      return this.http.get<VendaOrcamentoCabecalho[]>(this.url + 'lista/' + codigo);
    }
  }

  getVendaOrcamentoCabecalho(id: number): Observable<VendaOrcamentoCabecalho> {
    return this.http.get<VendaOrcamentoCabecalho>(this.url + id);
  }

  salvar(vendaOrcamentoCabecalho: VendaOrcamentoCabecalho): Observable<VendaOrcamentoCabecalho> {
    return this.http.post<VendaOrcamentoCabecalho>(this.url, vendaOrcamentoCabecalho, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
