import { TestBed, inject } from '@angular/core/testing';

import { VendaCondicoesPagamentoService } from './venda-condicoes-pagamento.service';

describe('VendaCondicoesPagamentoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [VendaCondicoesPagamentoService]
    });
  });

  it('should be created', inject([VendaCondicoesPagamentoService], (service: VendaCondicoesPagamentoService) => {
    expect(service).toBeTruthy();
  }));
});
