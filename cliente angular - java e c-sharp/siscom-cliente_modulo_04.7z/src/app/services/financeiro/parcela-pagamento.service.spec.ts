import { TestBed, inject } from '@angular/core/testing';

import { ParcelaPagamentoService } from './parcela-pagamento.service';

describe('ParcelaPagamentoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ParcelaPagamentoService]
    });
  });

  it('should be created', inject([ParcelaPagamentoService], (service: ParcelaPagamentoService) => {
    expect(service).toBeTruthy();
  }));
});
