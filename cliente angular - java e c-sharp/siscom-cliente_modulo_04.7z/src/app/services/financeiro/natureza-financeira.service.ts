import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';

import { FinNaturezaFinanceira } from './../../classes/financeiro/fin-natureza-financeira';

@Injectable({
  providedIn: 'root'
})
export class NaturezaFinanceiraService {

  private url = environment.urlBaseServidor + 'financeiro/natureza-financeira/';

  constructor(private http: HttpClient) { }

  getListaFinNaturezaFinanceira(nome: String): Observable<FinNaturezaFinanceira[]> {
    if (nome == null) {
      return this.http.get<FinNaturezaFinanceira[]>(this.url);
    } else {
      return this.http.get<FinNaturezaFinanceira[]>(this.url + 'lista/' + nome);
    }
  }

  getFinNaturezaFinanceira(id: number): Observable<FinNaturezaFinanceira> {
    return this.http.get<FinNaturezaFinanceira>(this.url + id);
  }

  salvar(naturezaFinanceira: FinNaturezaFinanceira): Observable<FinNaturezaFinanceira> {
    return this.http.post<FinNaturezaFinanceira>(this.url, naturezaFinanceira, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
