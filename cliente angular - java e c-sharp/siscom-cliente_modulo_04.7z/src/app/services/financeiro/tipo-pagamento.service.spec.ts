import { TestBed, inject } from '@angular/core/testing';

import { TipoPagamentoService } from './tipo-pagamento.service';

describe('TipoPagamentoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TipoPagamentoService]
    });
  });

  it('should be created', inject([TipoPagamentoService], (service: TipoPagamentoService) => {
    expect(service).toBeTruthy();
  }));
});
