import { TestBed, inject } from '@angular/core/testing';

import { LancamentoPagarService } from './lancamento-pagar.service';

describe('LancamentoPagarService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LancamentoPagarService]
    });
  });

  it('should be created', inject([LancamentoPagarService], (service: LancamentoPagarService) => {
    expect(service).toBeTruthy();
  }));
});
