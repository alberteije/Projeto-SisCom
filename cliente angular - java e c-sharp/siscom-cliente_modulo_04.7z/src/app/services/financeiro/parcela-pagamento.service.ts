import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';

import { FinParcelaPagar } from './../../classes/financeiro/fin-parcela-pagar';

@Injectable({
  providedIn: 'root'
})
export class ParcelaPagamentoService {

  private url = environment.urlBaseServidor + 'financeiro/parcela-pagamento/';

  constructor(private http: HttpClient) { }

  getListaFinParcelaPagar(): Observable<FinParcelaPagar[]> {
      return this.http.get<FinParcelaPagar[]>(this.url);
  }

  getFinParcelaPagar(id: number): Observable<FinParcelaPagar> {
    return this.http.get<FinParcelaPagar>(this.url + id);
  }

  salvar(parcelaPagamento: FinParcelaPagar): Observable<FinParcelaPagar> {
    return this.http.post<FinParcelaPagar>(this.url, parcelaPagamento, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
