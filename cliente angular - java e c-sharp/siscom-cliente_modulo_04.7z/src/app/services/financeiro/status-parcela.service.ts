import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';

import { FinStatusParcela } from './../../classes/financeiro/fin-status-parcela';

@Injectable({
  providedIn: 'root'
})
export class StatusParcelaService {

  private url = environment.urlBaseServidor + 'financeiro/status-parcela/';

  constructor(private http: HttpClient) { }

  getListaFinStatusParcela(nome: String): Observable<FinStatusParcela[]> {
    if (nome == null) {
      return this.http.get<FinStatusParcela[]>(this.url);
    } else {
      return this.http.get<FinStatusParcela[]>(this.url + 'lista/' + nome);
    }
  }

  getFinStatusParcela(id: number): Observable<FinStatusParcela> {
    return this.http.get<FinStatusParcela>(this.url + id);
  }

  salvar(statusParcela: FinStatusParcela): Observable<FinStatusParcela> {
    return this.http.post<FinStatusParcela>(this.url, statusParcela, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
