import { FinDocumentoOrigem } from './../../classes/financeiro/fin-documento-origem';
import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class DocumentoOrigemService {

  private url = environment.urlBaseServidor + 'financeiro/documento-origem/';

  constructor(private http: HttpClient) { }

  getListaFinDocumentoOrigem(nome: String): Observable<FinDocumentoOrigem[]> {
    if (nome == null) {
      return this.http.get<FinDocumentoOrigem[]>(this.url);
    } else {
      return this.http.get<FinDocumentoOrigem[]>(this.url + 'lista/' + nome);
    }
  }

  getFinDocumentoOrigem(id: number): Observable<FinDocumentoOrigem> {
    return this.http.get<FinDocumentoOrigem>(this.url + id);
  }

  salvar(documentoOrigem: FinDocumentoOrigem): Observable<FinDocumentoOrigem> {
    return this.http.post<FinDocumentoOrigem>(this.url, documentoOrigem, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
