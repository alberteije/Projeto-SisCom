import { TestBed, inject } from '@angular/core/testing';

import { NaturezaFinanceiraService } from './natureza-financeira.service';

describe('NaturezaFinanceiraService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [NaturezaFinanceiraService]
    });
  });

  it('should be created', inject([NaturezaFinanceiraService], (service: NaturezaFinanceiraService) => {
    expect(service).toBeTruthy();
  }));
});
