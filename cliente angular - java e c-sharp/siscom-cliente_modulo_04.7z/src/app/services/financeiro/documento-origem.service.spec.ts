import { TestBed, inject } from '@angular/core/testing';

import { DocumentoOrigemService } from './documento-origem.service';

describe('DocumentoOrigemService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DocumentoOrigemService]
    });
  });

  it('should be created', inject([DocumentoOrigemService], (service: DocumentoOrigemService) => {
    expect(service).toBeTruthy();
  }));
});
