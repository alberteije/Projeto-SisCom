import { TestBed, inject } from '@angular/core/testing';

import { EstoqueContagemService } from './estoque-contagem.service';

describe('EstoqueContagemService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EstoqueContagemService]
    });
  });

  it('should be created', inject([EstoqueContagemService], (service: EstoqueContagemService) => {
    expect(service).toBeTruthy();
  }));
});
