import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';
import { environment } from './../../../environments/environment';

import { EstoqueContagemCabecalho } from './../../classes/estoque/estoque-contagem-cabecalho';

@Injectable({
  providedIn: 'root'
})
export class EstoqueContagemService {

  private url = environment.urlBaseServidor + 'estoque/contagem/';

  constructor(private http: HttpClient) {  }

  getListaEstoqueContagemCabecalho(): Observable<EstoqueContagemCabecalho[]> {
    return this.http.get<EstoqueContagemCabecalho[]>(this.url);
  }

  getEstoqueContagemCabecalho(id: number): Observable<EstoqueContagemCabecalho> {
    return this.http.get<EstoqueContagemCabecalho>(this.url + id);
  }

  salvar(estoqueContagemCabecalho: EstoqueContagemCabecalho): Observable<EstoqueContagemCabecalho> {
    return this.http.post<EstoqueContagemCabecalho>(this.url, estoqueContagemCabecalho, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
