import { TestBed, inject } from '@angular/core/testing';

import { EstoqueReajusteService } from './estoque-reajuste.service';

describe('EstoqueReajusteService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EstoqueReajusteService]
    });
  });

  it('should be created', inject([EstoqueReajusteService], (service: EstoqueReajusteService) => {
    expect(service).toBeTruthy();
  }));
});
