import { TestBed, inject } from '@angular/core/testing';

import { CompraTipoRequisicaoService } from './compra-tipo-requisicao.service';

describe('CompraTipoRequisicaoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CompraTipoRequisicaoService]
    });
  });

  it('should be created', inject([CompraTipoRequisicaoService], (service: CompraTipoRequisicaoService) => {
    expect(service).toBeTruthy();
  }));
});
