import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';
import { environment } from './../../../environments/environment';

import { CompraTipoRequisicao } from './../../classes/compras/compra-tipo-requisicao';

@Injectable({
  providedIn: 'root'
})
export class CompraTipoRequisicaoService {

  private url = environment.urlBaseServidor + 'compra-tipo-requisicao';

  constructor(private http: HttpClient) {  }

  getCompraTipoRequisicaos(): Observable<CompraTipoRequisicao[]> {
    return this.http.get<CompraTipoRequisicao[]>(this.url);
  }

  getListaCompraTipoRequisicao(nome: string): Observable<CompraTipoRequisicao[]> {
    return this.http.get<CompraTipoRequisicao[]>(this.url + 'lista/' + nome);
  }

  getCompraTipoRequisicao(id: number): Observable<CompraTipoRequisicao> {
    return this.http.get<CompraTipoRequisicao>(this.url + id);
  }

  salvar(compraTipoRequisicao: CompraTipoRequisicao): Observable<CompraTipoRequisicao> {
    return this.http.post<CompraTipoRequisicao>(this.url, compraTipoRequisicao, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
