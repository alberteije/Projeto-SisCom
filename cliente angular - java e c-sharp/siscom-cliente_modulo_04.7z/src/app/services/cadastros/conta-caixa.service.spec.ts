import { TestBed, inject } from '@angular/core/testing';

import { ContaCaixaService } from './conta-caixa.service';

describe('ContaCaixaService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ContaCaixaService]
    });
  });

  it('should be created', inject([ContaCaixaService], (service: ContaCaixaService) => {
    expect(service).toBeTruthy();
  }));
});
