import { VariaveisGlobais } from './../../../../classes/variaveis-globais';
import { ParcelaPagamentoService } from './../../../../services/financeiro/parcela-pagamento.service';
import { FinParcelaPagar } from './../../../../classes/financeiro/fin-parcela-pagar';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { Location } from '../../../../../../node_modules/@angular/common';
import { FormBuilder } from '../../../../../../node_modules/@angular/forms';
import { ObjectUtils } from '../../../../../../node_modules/primeng/components/utils/objectutils';
import { ContaCaixa } from '../../../../classes/cadastros/conta-caixa';
import { FinStatusParcela } from '../../../../classes/financeiro/fin-status-parcela';

@Component({
  selector: 'app-parcela-pagamento-detalhe',
  templateUrl: './parcela-pagamento-detalhe.component.html',
  styleUrls: ['./parcela-pagamento-detalhe.component.css']
})
export class ParcelaPagamentoDetalheComponent implements OnInit {

  parcelaPagar: FinParcelaPagar;

  cols: any[];

  constructor(private parcelaPagamentoService: ParcelaPagamentoService,
    private route: ActivatedRoute,
    private location: Location,
    private router: Router,
    private global: VariaveisGlobais,
    private fb: FormBuilder,
    private objectUtils: ObjectUtils) { }

  ngOnInit() {

    this.cols = [
      { field: 'finTipoPagamento.descricao', header: 'Tipo Pagamento' },
      { field: 'contaCaixa.nome', header: 'Conta Caixa' },
      { field: 'dataPagamento', header: 'Data Pagamento' },
      { field: 'valorPago', header: 'Valor' }
    ];

    this.global.tituloJanela = "Pagamento de Parcela";
    this.parcelaPagar = new FinParcelaPagar();
    this.parcelaPagar.contaCaixa = new ContaCaixa();
    this.parcelaPagar.finStatusParcela = new FinStatusParcela();

    let id = this.route.snapshot.paramMap.get('id');
    this.parcelaPagamentoService.getFinParcelaPagar(parseInt(id, 0)).subscribe(
      obj => {
        this.parcelaPagar = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  resolveFieldData(data, field) {
    return this.objectUtils.resolveFieldData(data, field);
  }

  retornar() {
    this.location.back();
  }

  salvar() {
    this.parcelaPagamentoService.salvar(this.parcelaPagar).subscribe(
      obj => {
        this.parcelaPagar = obj;
        this.global.mostraMensagem(this.global.info, "Confirmação", 'Registro salvo com sucesso');
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

}
