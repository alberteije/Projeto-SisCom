import { VariaveisGlobais } from './../../../classes/variaveis-globais';
import { ConfirmationService } from 'primeng/api';
import { ParcelaPagamentoService } from './../../../services/financeiro/parcela-pagamento.service';
import { FinParcelaPagar } from './../../../classes/financeiro/fin-parcela-pagar';
import { Component, OnInit } from '@angular/core';
import { ObjectUtils } from '../../../../../node_modules/primeng/components/utils/objectutils';

@Component({
  selector: 'app-parcela-pagamento',
  templateUrl: './parcela-pagamento.component.html',
  styleUrls: ['./parcela-pagamento.component.css']
})
export class ParcelaPagamentoComponent implements OnInit {

  listaParcelaPagar: FinParcelaPagar[];
  cols: any[];
  parcelaPagarSelecionado: FinParcelaPagar;
  botoesDesabilitados: boolean = true;

  constructor(private parcelaPagamentoService: ParcelaPagamentoService,
    private confirmationService: ConfirmationService,
    private global: VariaveisGlobais,
    private objectUtils: ObjectUtils) { }

  ngOnInit() {
    this.global.tituloJanela = "Pagamento de Parcela";
    this.carregaDados();

    this.cols = [
      { field: 'contaCaixa.nome', header: 'Conta Caixa' },
      { field: 'finStatusParcela.descricao', header: 'Status' },
      { field: 'valor', header: 'Valor' }
    ];
  }

  resolveFieldData(data, field) {
    return this.objectUtils.resolveFieldData(data, field);
  }

  private carregaDados() {
    this.parcelaPagamentoService.getListaFinParcelaPagar().subscribe(
      lista => {
        this.listaParcelaPagar = lista;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  onRowSelect(event) {
    this.botoesDesabilitados = false;
  }

  onRowUnselect(event) {
    this.botoesDesabilitados = true;
  }

  getIdParcelaPagar() {
    return this.parcelaPagarSelecionado == null ? null : this.parcelaPagarSelecionado.id;
  }

}
