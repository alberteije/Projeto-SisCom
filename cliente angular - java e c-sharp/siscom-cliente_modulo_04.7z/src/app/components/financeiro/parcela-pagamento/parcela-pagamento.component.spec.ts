import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParcelaPagamentoComponent } from './parcela-pagamento.component';

describe('ParcelaPagamentoComponent', () => {
  let component: ParcelaPagamentoComponent;
  let fixture: ComponentFixture<ParcelaPagamentoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParcelaPagamentoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParcelaPagamentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
