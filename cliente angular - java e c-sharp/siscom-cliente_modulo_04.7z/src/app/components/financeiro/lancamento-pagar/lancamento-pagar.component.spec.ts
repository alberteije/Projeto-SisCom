import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LancamentoPagarComponent } from './lancamento-pagar.component';

describe('LancamentoPagarComponent', () => {
  let component: LancamentoPagarComponent;
  let fixture: ComponentFixture<LancamentoPagarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LancamentoPagarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LancamentoPagarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
