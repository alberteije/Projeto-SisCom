import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LancamentoPagarDetalheComponent } from './lancamento-pagar-detalhe.component';

describe('LancamentoPagarDetalheComponent', () => {
  let component: LancamentoPagarDetalheComponent;
  let fixture: ComponentFixture<LancamentoPagarDetalheComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LancamentoPagarDetalheComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LancamentoPagarDetalheComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
