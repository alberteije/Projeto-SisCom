import { Component, OnInit } from '@angular/core';
import { ObjectUtils } from '../../../../../node_modules/primeng/components/utils/objectutils';

import { VariaveisGlobais } from './../../../classes/variaveis-globais';
import { ConfirmationService } from 'primeng/api';
import { CompraRequisicaoService } from './../../../services/compras/compra-requisicao.service';
import { CompraRequisicao } from './../../../classes/compras/compra-requisicao';

@Component({
  selector: 'app-compra-requisicao',
  templateUrl: './compra-requisicao.component.html',
  styleUrls: ['./compra-requisicao.component.css']
})
export class CompraRequisicaoComponent implements OnInit {

  listaCompraRequisicao: CompraRequisicao[];
  cols: any[];
  compraRequisicaoSelecionado: CompraRequisicao;
  botoesDesabilitados: boolean = true;

  constructor(private compraRequisicaoService: CompraRequisicaoService,
    private confirmationService: ConfirmationService,
    private global: VariaveisGlobais,
    private objectUtils: ObjectUtils) { }

  ngOnInit() {
    this.global.tituloJanela = "Lista de Requisicões";
    this.carregaDados();

    this.cols = [
      { field: 'compraTipoRequisicao.nome', header: 'Tipo Requisição' },
      { field: 'colaborador.pessoa.nome', header: 'Colaborador' },
      { field: 'dataRequisicao', header: 'Data' }
    ];
  }

  resolveFieldData(data, field) {
    return this.objectUtils.resolveFieldData(data, field);
  }

  private carregaDados() {
    this.compraRequisicaoService.getListaCompraRequisicao().subscribe(
      lista => {
        this.listaCompraRequisicao = lista;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  onRowSelect(event) {
    this.botoesDesabilitados = false;
  }

  onRowUnselect(event) {
    this.botoesDesabilitados = true;
  }

  getIdCompraRequisicao() {
    return this.compraRequisicaoSelecionado == null ? null : this.compraRequisicaoSelecionado.id;
  }

  excluir() {
    this.confirmationService.confirm({
      message: 'Excluir o registro selecionado?',
      header: 'Confirmação',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.compraRequisicaoService.excluir(this.compraRequisicaoSelecionado.id).subscribe(
          _ => {
            this.carregaDados();
            this.botoesDesabilitados = true;
            this.global.mostraMensagem(this.global.info, "Confirmação", 'Registro excluído com sucesso');
          },
          error => {
            this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
          }
        );
      },
      reject: () => {
        //this.msgs = [{ severity: 'info', summary: 'Rejected', detail: 'You have rejected' }];
      }
    });
  }
}
