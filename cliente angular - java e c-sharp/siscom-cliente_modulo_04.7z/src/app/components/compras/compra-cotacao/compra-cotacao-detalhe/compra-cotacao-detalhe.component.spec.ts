import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompraCotacaoDetalheComponent } from './compra-cotacao-detalhe.component';

describe('CompraCotacaoDetalheComponent', () => {
  let component: CompraCotacaoDetalheComponent;
  let fixture: ComponentFixture<CompraCotacaoDetalheComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompraCotacaoDetalheComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompraCotacaoDetalheComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
