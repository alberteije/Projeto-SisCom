import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContagemDetalheComponent } from './contagem-detalhe.component';

describe('ContagemDetalheComponent', () => {
  let component: ContagemDetalheComponent;
  let fixture: ComponentFixture<ContagemDetalheComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContagemDetalheComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContagemDetalheComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
