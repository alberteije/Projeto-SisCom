import { EstoqueContagemDetalhe } from './../../../../classes/estoque/estoque-contagem-detalhe';
import { VariaveisGlobais } from './../../../../classes/variaveis-globais';
import { ProdutoService } from './../../../../services/cadastros/produto.service';
import { EstoqueContagemService } from './../../../../services/estoque/estoque-contagem.service';
import { Produto } from './../../../../classes/cadastros/produto';
import { EstoqueContagemCabecalho } from './../../../../classes/estoque/estoque-contagem-cabecalho';
import { Component, OnInit } from '@angular/core';
import { SelectItem } from '../../../../../../node_modules/primeng/api';
import { FormGroup, FormBuilder, FormControl, Validators } from '../../../../../../node_modules/@angular/forms';
import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { Location } from '../../../../../../node_modules/@angular/common';
import { ObjectUtils } from '../../../../../../node_modules/primeng/components/utils/objectutils';

@Component({
  selector: 'app-contagem-detalhe',
  templateUrl: './contagem-detalhe.component.html',
  styleUrls: ['./contagem-detalhe.component.css']
})
export class ContagemDetalheComponent implements OnInit {

  opcoesEstoqueAtualizado: SelectItem[];

  estoqueContagem: EstoqueContagemCabecalho;
  userform: FormGroup;

  cols: any[];
  display: boolean = false;
  filtroProduto: Produto[];
  produto: Produto;
  quantidade: number;

  constructor(private estoqueContagemService: EstoqueContagemService,
    private produtoService: ProdutoService,
    private route: ActivatedRoute,
    private location: Location,
    private router: Router,
    private global: VariaveisGlobais,
    private fb: FormBuilder,
    private objectUtils: ObjectUtils) { }

  ngOnInit() {
    this.opcoesEstoqueAtualizado = [
      { label: 'Sim', value: 'S' },
      { label: 'Não', value: 'N' },
    ];

    this.userform = this.fb.group({
      'id': new FormControl(''),
      'dataContagem': new FormControl('', Validators.required),
      'estoqueAtualizado': new FormControl('', Validators.required)
    });

    this.cols = [
      { field: 'produto.nome', header: 'Produto' },
      { field: 'quantidadeContada', header: 'Qtde Contada' },
      { field: 'quantidadeSistema', header: 'Qtde Sistema' },
      { field: 'acuracidade', header: 'Acuracidade' },
      { field: 'divergencia', header: 'Divergência' },
    ];

    this.global.tituloJanela = "Detalhe Contagem";
    this.estoqueContagem = new EstoqueContagemCabecalho();
    this.estoqueContagem.listaEstoqueContagemDetalhe = [];

    if (this.router.url !== '/estoque-contagem/novo') {
      let id = this.route.snapshot.paramMap.get('id');
      this.estoqueContagemService.getEstoqueContagemCabecalho(parseInt(id, 0)).subscribe(
        obj => {
          this.estoqueContagem = obj;
          this.userform.patchValue(this.estoqueContagem);
        },
        error => {
          this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
        }
      );
    }
  }

  resolveFieldData(data, field) {
    return this.objectUtils.resolveFieldData(data, field);
  }

  retornar() {
    this.location.back();
  }

  salvar() {
    this.estoqueContagemService.salvar(this.estoqueContagem).subscribe(
      obj => {
        this.estoqueContagem = obj;
        this.global.mostraMensagem(this.global.info, "Confirmação", 'Registro salvo com sucesso');
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  buscaProduto(event) {
    this.produtoService.getListaProduto(event.query).subscribe(
      obj => {
        this.filtroProduto = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  onSubmit(value) {
    let listaDetalhe: EstoqueContagemDetalhe[] = this.estoqueContagem.listaEstoqueContagemDetalhe;
    this.estoqueContagem = value as EstoqueContagemCabecalho;
    this.estoqueContagem.listaEstoqueContagemDetalhe = listaDetalhe;
    this.salvar();
  }

  novoDetalhe() {
    this.display = true;
  }

  cancelaInclusao() {
    this.display = false;
  }

  incluirProduto() {
    let detalhe: EstoqueContagemDetalhe = new EstoqueContagemDetalhe();
    detalhe.produto = this.produto;
    detalhe.quantidadeContada = this.quantidade;
    this.estoqueContagem.listaEstoqueContagemDetalhe.push(detalhe);

    this.display = false;
  }

}
