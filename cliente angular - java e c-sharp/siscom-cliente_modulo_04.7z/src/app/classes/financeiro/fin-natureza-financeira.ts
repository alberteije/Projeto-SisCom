export class FinNaturezaFinanceira {
	id: number;
	codigo: string;
	descricao: string;
}
