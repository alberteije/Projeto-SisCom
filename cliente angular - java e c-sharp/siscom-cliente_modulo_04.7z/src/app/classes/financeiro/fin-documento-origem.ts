export class FinDocumentoOrigem {
	id: number;
	codigo: string;
	siglaDocumento: string;
	descricao: string;
}
