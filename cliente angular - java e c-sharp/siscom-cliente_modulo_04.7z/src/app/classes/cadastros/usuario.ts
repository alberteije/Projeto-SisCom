import { Colaborador } from './colaborador';
import { Papel } from './papel';

export class Usuario {
	id: number;
	colaborador: Colaborador;
	papel: Papel;
	login: string;
	senha: string;
	dataCadastro: string;
	administrador: string;
	token: string;
}
