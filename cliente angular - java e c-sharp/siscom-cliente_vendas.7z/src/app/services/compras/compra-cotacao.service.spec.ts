import { TestBed, inject } from '@angular/core/testing';

import { CompraCotacaoService } from './compra-cotacao.service';

describe('CompraCotacaoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CompraCotacaoService]
    });
  });

  it('should be created', inject([CompraCotacaoService], (service: CompraCotacaoService) => {
    expect(service).toBeTruthy();
  }));
});
