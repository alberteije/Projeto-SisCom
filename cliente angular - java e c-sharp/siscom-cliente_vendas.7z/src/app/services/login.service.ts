import { Injectable } from '@angular/core';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { Observable, of } from '../../../node_modules/rxjs';
import { tap } from 'rxjs/operators';

import { Usuario } from './../classes/cadastros/usuario';
import { Router } from '../../../node_modules/@angular/router';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  url = environment.urlBaseServidor + 'login';
  usuario: Usuario;

  constructor(private http: HttpClient,
    private router: Router) {
    this.usuario = new Usuario();
  }

  login(usuario: Usuario): Observable<Usuario> {
    return this.http.post<Usuario>(this.url, usuario, environment.httpOptions)
      .pipe(tap(
        data => {
          this.usuario = data as Usuario;
          localStorage.setItem('usuarioSessao', JSON.stringify(this.usuario));
        }
      ));
    /*this.usuarioLogado = true;
    return of<Usuario>(usuario);*/
  }

  logout() {
    localStorage.removeItem('usuarioSessao');
    this.router.navigate(['/login']);
  }

  getUsuarioLogado() {
    if (localStorage.getItem('usuarioSessao') != null) {
      return true;
    }
    return false;
  }
}
