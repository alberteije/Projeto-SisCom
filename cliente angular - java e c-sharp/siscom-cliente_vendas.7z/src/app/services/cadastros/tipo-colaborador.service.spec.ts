import { TestBed, inject } from '@angular/core/testing';

import { TipoColaboradorService } from './tipo-colaborador.service';

describe('TipoColaboradorService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TipoColaboradorService]
    });
  });

  it('should be created', inject([TipoColaboradorService], (service: TipoColaboradorService) => {
    expect(service).toBeTruthy();
  }));
});
