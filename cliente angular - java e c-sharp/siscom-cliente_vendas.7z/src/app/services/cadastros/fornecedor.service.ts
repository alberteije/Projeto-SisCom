import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';
import { environment } from './../../../environments/environment';

import { Fornecedor } from './../../classes/cadastros/fornecedor';

@Injectable({
  providedIn: 'root'
})
export class FornecedorService {

  private url = environment.urlBaseServidor + 'fornecedor/';

  constructor(private http: HttpClient) {  }

  getFornecedors(): Observable<Fornecedor[]> {
    return this.http.get<Fornecedor[]>(this.url);
  }

  getListaFornecedor(nome: string): Observable<Fornecedor[]> {
    return this.http.get<Fornecedor[]>(this.url + 'lista/' + nome);
  }

  getFornecedor(id: number): Observable<Fornecedor> {
    return this.http.get<Fornecedor>(this.url + id);
  }

  salvar(Fornecedor: Fornecedor): Observable<Fornecedor> {
    return this.http.post<Fornecedor>(this.url, Fornecedor, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
