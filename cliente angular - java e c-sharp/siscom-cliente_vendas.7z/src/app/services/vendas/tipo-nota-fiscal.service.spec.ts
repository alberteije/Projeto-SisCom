import { TestBed, inject } from '@angular/core/testing';

import { TipoNotaFiscalService } from './tipo-nota-fiscal.service';

describe('TipoNotaFiscalService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TipoNotaFiscalService]
    });
  });

  it('should be created', inject([TipoNotaFiscalService], (service: TipoNotaFiscalService) => {
    expect(service).toBeTruthy();
  }));
});
