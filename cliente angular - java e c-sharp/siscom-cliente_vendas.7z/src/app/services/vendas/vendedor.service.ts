import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';
import { Vendedor } from '../../classes/cadastros/vendedor';

@Injectable({
  providedIn: 'root'
})
export class VendedorService {

  private url = environment.urlBaseServidor + 'vendedor/';

  constructor(private http: HttpClient) {  }

  getListaVendedor(codigo?: String): Observable<Vendedor[]> {
    if (codigo == null) {
      return this.http.get<Vendedor[]>(this.url);
    } else {
      return this.http.get<Vendedor[]>(this.url + 'lista/' + codigo);
    }
  }

  getVendedor(id: number): Observable<Vendedor> {
    return this.http.get<Vendedor>(this.url + id);
  }

  salvar(vendedor: Vendedor): Observable<Vendedor> {
    return this.http.post<Vendedor>(this.url, vendedor, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
