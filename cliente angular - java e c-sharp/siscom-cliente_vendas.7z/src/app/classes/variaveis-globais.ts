import { Injectable } from "../../../node_modules/@angular/core";
import { HttpHeaders, HttpErrorResponse } from "../../../node_modules/@angular/common/http";
import { Router } from "../../../node_modules/@angular/router";

import { Message } from 'primeng/api';

import { LoginService } from './../services/login.service';

@Injectable({
    providedIn: 'root'
})
export class VariaveisGlobais {

    constructor(private router: Router,
        private loginService: LoginService) { }

    tituloJanela = 'T2Ti.com - SisCom';

    msgs: Message[] = [];
    success = 'success';
    info = 'info';
    warn = 'warn';
    error = 'error';

    mostraMensagem(tipo: string, titulo: string, mensagem: string) {
        this.msgs = [{ severity: tipo, summary: titulo, detail: mensagem }];
    }

    trataErro(error: HttpErrorResponse): string {
        console.log(error);
        if (error.status === 404) {
            this.router.navigate(['nao-encontrado']);
        }
        if (error.status === 401) {
            this.loginService.logout();
        }

        if (error.error) {
            return error.error.message;
        } else {
            return 'Erro desconhecido';
        }
    }
}
