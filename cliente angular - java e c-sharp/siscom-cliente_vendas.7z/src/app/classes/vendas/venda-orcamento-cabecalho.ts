import { VendaOrcamentoDetalhe } from './venda-orcamento-detalhe';
import { Cliente } from './../cadastros/cliente';
import { Transportadora } from './../cadastros/transportadora';
import { Vendedor } from './../cadastros/vendedor';
import { VendaCondicoesPagamento } from './venda-condicoes-pagamento';

export class VendaOrcamentoCabecalho {
	id: number;
	vendaCondicoesPagamento: VendaCondicoesPagamento;
	vendedor: Vendedor;
	transportadora: Transportadora;
	cliente: Cliente;
	tipo: string;
	codigo: string;
	dataCadastro: string;
	validade: string;
	tipoFrete: string;
	valorSubtotal: number;
	valorFrete: number;
	taxaComissao: number;
	valorComissao: number;
	taxaDesconto: number;
	valorDesconto: number;
	valorTotal: number;
	observacao: string;
	listaVendaOrcamentoDetalhe: VendaOrcamentoDetalhe[];
}
