export class ProdutoMarca {
	id: number;
	nome: string;
	descricao: string;
}
