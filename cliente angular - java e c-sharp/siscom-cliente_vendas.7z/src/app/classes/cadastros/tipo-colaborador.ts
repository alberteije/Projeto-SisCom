export class TipoColaborador {
	id: number;
	nome: string;
	descricao: string;
}
