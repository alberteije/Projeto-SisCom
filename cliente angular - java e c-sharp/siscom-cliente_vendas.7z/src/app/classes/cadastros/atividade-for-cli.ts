export class AtividadeForCli {
	id: number;
	nome: string;
	descricao: string;
}
