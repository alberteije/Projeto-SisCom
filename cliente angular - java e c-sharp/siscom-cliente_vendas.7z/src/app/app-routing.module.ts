import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from './components/login/login.component';
import { CargoComponent } from './components/cadastros/cargo/cargo.component';
import { CargoDetalheComponent } from './components/cadastros/cargo/cargo-detalhe/cargo-detalhe.component';
import { ColaboradorDetalheComponent } from './components/cadastros/colaborador/colaborador-detalhe/colaborador-detalhe.component';
import { ColaboradorComponent } from './components/cadastros/colaborador/colaborador.component';
import { CompraRequisicaoDetalheComponent } from './components/compras/compra-requisicao/compra-requisicao-detalhe/compra-requisicao-detalhe.component';
import { CompraRequisicaoComponent } from './components/compras/compra-requisicao/compra-requisicao.component';
import { CompraCotacaoDetalheComponent } from './components/compras/compra-cotacao/compra-cotacao-detalhe/compra-cotacao-detalhe.component';
import { CompraCotacaoComponent } from './components/compras/compra-cotacao/compra-cotacao.component';
import { OrcamentoDetalheComponent } from './components/vendas/orcamento/orcamento-detalhe/orcamento-detalhe.component';
import { OrcamentoComponent } from './components/vendas/orcamento/orcamento.component';

import { NaoEncontradoComponent } from './components/nao-encontrado/nao-encontrado.component';
import { HomeComponent } from './components/home/home.component';
import { AuthGuardService } from './auth-guard.service';

const routes: Routes = [
  {
    path: '', canActivate: [AuthGuardService],
    children: [
      { path: '', component: HomeComponent },
      { path: 'cargo', component: CargoComponent },
      { path: 'cargo/novo', component: CargoDetalheComponent },
      { path: 'cargo/:id', component: CargoDetalheComponent },
      { path: 'colaborador', component: ColaboradorComponent },
      { path: 'colaborador/novo', component: ColaboradorDetalheComponent },
      { path: 'colaborador/:id', component: ColaboradorDetalheComponent },
      { path: 'compra-requisicao', component: CompraRequisicaoComponent },
      { path: 'compra-requisicao/novo', component: CompraRequisicaoDetalheComponent },
      { path: 'compra-requisicao/:id', component: CompraRequisicaoDetalheComponent },
      { path: 'compra-cotacao', component: CompraCotacaoComponent },
      { path: 'compra-cotacao/novo', component: CompraCotacaoDetalheComponent },
      { path: 'compra-cotacao/:id', component: CompraCotacaoDetalheComponent },
      { path: 'venda-orcamento', component: OrcamentoComponent },
      { path: 'venda-orcamento/novo', component: OrcamentoDetalheComponent },
      { path: 'venda-orcamento/:id', component: OrcamentoDetalheComponent },
      { path: 'nao-encontrado', component: NaoEncontradoComponent }
    ]
  },
  { path: 'login', component: LoginComponent }
];

@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forRoot(routes)]
})
export class AppRoutingModule { }
