import { VariaveisGlobais } from './../../../classes/variaveis-globais';
import { ConfirmationService } from 'primeng/api';
import { CompraCotacaoService } from './../../../services/compras/compra-cotacao.service';
import { CompraCotacao } from './../../../classes/compras/compra-cotacao';
import { Component, OnInit } from '@angular/core';
import { ObjectUtils } from '../../../../../node_modules/primeng/components/utils/objectutils';

@Component({
  selector: 'app-compra-cotacao',
  templateUrl: './compra-cotacao.component.html',
  styleUrls: ['./compra-cotacao.component.css']
})
export class CompraCotacaoComponent implements OnInit {

  listaCompraCotacao: CompraCotacao[];
  cols: any[];
  compraCotacaoSelecionado: CompraCotacao;
  botoesDesabilitados: boolean = true;

  constructor(private compraCotacaoService: CompraCotacaoService,
    private confirmationService: ConfirmationService,
    private global: VariaveisGlobais,
    private objectUtils: ObjectUtils) { }

  ngOnInit() {
    this.global.tituloJanela = "Lista de Cotações";
    this.carregaDados();

    this.cols = [
      { field: 'dataCotacao', header: 'Data' },
      { field: 'descricao', header: 'Descrição' },
      { field: 'situacao', header: 'Situação' }
    ];
  }

  resolveFieldData(data, field) {
    return this.objectUtils.resolveFieldData(data, field);
  }

  private carregaDados() {
    this.compraCotacaoService.getListaCompraCotacao().subscribe(
      lista => {
        this.listaCompraCotacao = lista;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  onRowSelect(event) {
    this.botoesDesabilitados = false;
  }

  onRowUnselect(event) {
    this.botoesDesabilitados = true;
  }

  getIdCompraCotacao() {
    return this.compraCotacaoSelecionado == null ? null : this.compraCotacaoSelecionado.id;
  }

  excluir() {
    this.confirmationService.confirm({
      message: 'Excluir o registro selecionado?',
      header: 'Confirmação',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.compraCotacaoService.excluir(this.compraCotacaoSelecionado.id).subscribe(
          _ => {
            this.carregaDados();
            this.botoesDesabilitados = true;
            this.global.mostraMensagem(this.global.info, "Confirmação", 'Registro excluído com sucesso');
          },
          error => {
            this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
          }
        );
      },
      reject: () => {
        //this.msgs = [{ severity: 'info', summary: 'Rejected', detail: 'You have rejected' }];
      }
    });
  }
}
