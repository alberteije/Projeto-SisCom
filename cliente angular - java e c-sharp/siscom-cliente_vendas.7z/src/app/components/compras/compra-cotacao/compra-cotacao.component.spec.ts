import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompraCotacaoComponent } from './compra-cotacao.component';

describe('CompraCotacaoComponent', () => {
  let component: CompraCotacaoComponent;
  let fixture: ComponentFixture<CompraCotacaoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompraCotacaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompraCotacaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
