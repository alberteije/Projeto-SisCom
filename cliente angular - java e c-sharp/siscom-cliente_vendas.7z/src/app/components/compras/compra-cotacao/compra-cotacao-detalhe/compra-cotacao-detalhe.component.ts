import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '../../../../../../node_modules/@angular/forms';
import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { Location } from '../../../../../../node_modules/@angular/common';
import { ObjectUtils } from '../../../../../../node_modules/primeng/components/utils/objectutils';

import { FornecedorService } from './../../../../services/cadastros/fornecedor.service';
import { Fornecedor } from './../../../../classes/cadastros/fornecedor';
import { VariaveisGlobais } from './../../../../classes/variaveis-globais';
import { CompraCotacaoService } from './../../../../services/compras/compra-cotacao.service';
import { CompraCotacao } from './../../../../classes/compras/compra-cotacao';
import { CompraFornecedorCotacao } from '../../../../classes/compras/compra-fornecedor-cotacao';
import { CompraRequisicaoService } from '../../../../services/compras/compra-requisicao.service';
import { CompraRequisicaoDetalhe } from './../../../../classes/compras/compra-requisicao-detalhe';
import { CompraRequisicao } from './../../../../classes/compras/compra-requisicao';
import { CompraReqCotacaoDetalhe } from '../../../../classes/compras/compra-req-cotacao-detalhe';

@Component({
  selector: 'app-compra-cotacao-detalhe',
  templateUrl: './compra-cotacao-detalhe.component.html',
  styleUrls: ['./compra-cotacao-detalhe.component.css']
})
export class CompraCotacaoDetalheComponent implements OnInit {

  compraCotacao: CompraCotacao;
  userform: FormGroup;

  cols: any[];
  colsItem: any[];
  colsProduto: any[];

  displayFornecedor: boolean = false;
  fornecedor: Fornecedor;
  filtroFornecedor: Fornecedor[];

  displayProduto: boolean = false;
  requisicaoSelecionado: CompraRequisicaoDetalhe;
  listaCompraRequisicaoDetalhe: CompraRequisicaoDetalhe[];
  quantidade: number;
  /*-detalheSelecionado: CompraCotacaoDetalhe;
  filtroProduto: Produto[];
  indiceSelecionado: number;*/

  constructor(private compraCotacaoService: CompraCotacaoService,
    private fornecedorService: FornecedorService,
    private requisicaoService: CompraRequisicaoService,
    private route: ActivatedRoute,
    private location: Location,
    private router: Router,
    private global: VariaveisGlobais,
    private fb: FormBuilder,
    private objectUtils: ObjectUtils) { }

  ngOnInit() {
    this.userform = this.fb.group({
      'id': new FormControl(''),
      'descricao': new FormControl('', Validators.required),
      'dataCotacao': new FormControl('', Validators.required),
      'situacao': new FormControl('')
    });

    this.cols = [
      { field: 'fornecedor.pessoa.nome', header: 'Fornecedor' }
    ];

    this.colsItem = [
      { field: 'compraRequisicaoDetalhe.produto.nome', header: 'Produto' },
      { field: 'quantidadeCotada', header: 'Qtde Cotada' }
    ];

    this.colsProduto = [
      { field: 'produto.nome', header: 'Produto' },
      { field: 'quantidade', header: 'Qtde' }
    ];

    this.global.tituloJanela = "Detalhe Compra Cotação";
    this.compraCotacao = new CompraCotacao();
    //this.detalheSelecionado = new CompraCotacaoDetalhe();

    if (this.router.url !== '/compra-requisicao/novo') {
      let id = this.route.snapshot.paramMap.get('id');
      this.compraCotacaoService.getCompraCotacao(parseInt(id, 0)).subscribe(
        obj => {
          this.compraCotacao = obj;
          console.log(this.compraCotacao);
          this.userform.patchValue(this.compraCotacao);
        },
        error => {
          this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
        }
      );
    }
  }

  resolveFieldData(data, field) {
    return this.objectUtils.resolveFieldData(data, field);
  }

  retornar() {
    this.location.back();
  }

  salvar() {
    this.compraCotacaoService.salvar(this.compraCotacao).subscribe(
      obj => {
        this.compraCotacao = obj;
        this.global.mostraMensagem(this.global.info, "Confirmação", 'Registro salvo com sucesso');
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  buscaFornecedor(event) {
    this.fornecedorService.getListaFornecedor(event.query).subscribe(
      obj => {
        this.filtroFornecedor = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  novoFornecedor() {
    this.fornecedor = new Fornecedor();
    this.displayFornecedor = true;
  }

  incluirFornecedor() {
    let compraFornecedorCotacao: CompraFornecedorCotacao = new CompraFornecedorCotacao();
    compraFornecedorCotacao.fornecedor = this.fornecedor;

    this.compraCotacao.listaCompraFornecedorCotacao.push(compraFornecedorCotacao);
    this.displayFornecedor = false;
  }

  cancelaInclusao() {
    this.displayFornecedor = false;
    this.displayProduto = false;
  }

  novoItem() {
    this.displayProduto = true;
    this.requisicaoService.getListaCompraRequisicao().subscribe(
      obj => {
        this.listaCompraRequisicaoDetalhe = obj[0].listaCompraRequisicaoDetalhe;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );    
  }

  incluirProduto() {
    let reqCotacaoDetalhe: CompraReqCotacaoDetalhe = new CompraReqCotacaoDetalhe();
    reqCotacaoDetalhe.compraRequisicaoDetalhe = this.requisicaoSelecionado;
    reqCotacaoDetalhe.quantidadeCotada = this.quantidade;

    this.compraCotacao.listaCompraReqCotacaoDetalhe.push(reqCotacaoDetalhe);
    this.displayProduto = false;
  }

  onSubmit(value) {
    let listaFornecedor: CompraFornecedorCotacao[] = this.compraCotacao.listaCompraFornecedorCotacao;
    let listaReqDetalhe: CompraReqCotacaoDetalhe[] = this.compraCotacao.listaCompraReqCotacaoDetalhe;
    this.compraCotacao = value as CompraCotacao;
    this.compraCotacao.listaCompraFornecedorCotacao = listaFornecedor;
    this.compraCotacao.listaCompraReqCotacaoDetalhe = listaReqDetalhe;
    this.salvar();
  }

}
