import { ProdutoService } from './../../../../services/cadastros/produto.service';
import { Produto } from './../../../../classes/cadastros/produto';
import { VendaOrcamentoDetalhe } from './../../../../classes/vendas/venda-orcamento-detalhe';
import { VariaveisGlobais } from './../../../../classes/variaveis-globais';
import { VendedorService } from './../../../../services/vendas/vendedor.service';
import { ClienteService } from './../../../../services/cadastros/cliente.service';
import { VendaCondicoesPagamentoService } from './../../../../services/vendas/venda-condicoes-pagamento.service';
import { VendaOrcamentoService } from './../../../../services/vendas/venda-orcamento.service';
import { Vendedor } from './../../../../classes/cadastros/vendedor';
import { Cliente } from './../../../../classes/cadastros/cliente';
import { VendaCondicoesPagamento } from './../../../../classes/vendas/venda-condicoes-pagamento';
import { VendaOrcamentoCabecalho } from './../../../../classes/vendas/venda-orcamento-cabecalho';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '../../../../../../node_modules/@angular/forms';
import { Transportadora } from '../../../../classes/cadastros/transportadora';
import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { Location } from '../../../../../../node_modules/@angular/common';
import { ObjectUtils } from '../../../../../../node_modules/primeng/components/utils/objectutils';

@Component({
  selector: 'app-orcamento-detalhe',
  templateUrl: './orcamento-detalhe.component.html',
  styleUrls: ['./orcamento-detalhe.component.css']
})
export class OrcamentoDetalheComponent implements OnInit {

  orcamento: VendaOrcamentoCabecalho;
  userform: FormGroup;

  cols: any[];
  colsItem: any[];
  colsProduto: any[];

  condicaoPagamento: VendaCondicoesPagamento;
  filtroCondicaoPagamento: VendaCondicoesPagamento[];
  transportadora: Transportadora;
  filtroTransportadora: Transportadora[];
  cliente: Cliente;
  filtroCliente: Cliente[];
  vendedor: Vendedor;
  filtroVendedor: Vendedor[];

  display: boolean = false;
  quantidade: number;
  produto: Produto;
  filtroProduto: Produto[];

  constructor(private orcamentoService: VendaOrcamentoService,
    private condicaoPagamentoService: VendaCondicoesPagamentoService,
    private clienteService: ClienteService,
    private vendedorService: VendedorService,
    private produtoService: ProdutoService,
    private route: ActivatedRoute,
    private location: Location,
    private router: Router,
    private global: VariaveisGlobais,
    private fb: FormBuilder,
    private objectUtils: ObjectUtils) { }

  ngOnInit() {
    this.userform = this.fb.group({
      'id': new FormControl(''),
      'transportadora': new FormControl(''),
      'vendaCondicoesPagamento': new FormControl('', Validators.required),
      'cliente': new FormControl('', Validators.required),
      'vendedor': new FormControl('', Validators.required),
      'codigo': new FormControl(''),
      'valorTotal': new FormControl('')
    });

    this.cols = [
      { field: 'produto.nome', header: 'Produto' },
      { field: 'quantidade', header: 'Qtde' },
      { field: 'valorUnitario', header: 'Vlr. Unitário' },
      { field: 'valorTotal', header: 'Vlr. Total' }
    ];

    this.global.tituloJanela = "Detalhe Orçamento";
    this.orcamento = new VendaOrcamentoCabecalho();

    if (this.router.url !== '/venda-orcamento/novo') {
      let id = this.route.snapshot.paramMap.get('id');
      this.orcamentoService.getVendaOrcamentoCabecalho(parseInt(id, 0)).subscribe(
        obj => {
          this.orcamento = obj;
          console.log(this.orcamento);
          this.userform.patchValue(this.orcamento);
        },
        error => {
          this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
        }
      );
    }
  }

  resolveFieldData(data, field) {
    return this.objectUtils.resolveFieldData(data, field);
  }

  retornar() {
    this.location.back();
  }

  salvar() {
    this.orcamentoService.salvar(this.orcamento).subscribe(
      obj => {
        this.orcamento = obj;
        this.global.mostraMensagem(this.global.info, "Confirmação", 'Registro salvo com sucesso');
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  buscaCondicoesPagamento(event) {
    this.condicaoPagamentoService.getListaVendaCondicoesPagamento(event.query).subscribe(
      obj => {
        this.filtroCondicaoPagamento = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  buscaCliente(event) {
    this.clienteService.getListaCliente(event.query).subscribe(
      obj => {
        this.filtroCliente = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  buscaVendedor(event) {
    this.vendedorService.getListaVendedor(event.query).subscribe(
      obj => {
        this.filtroVendedor = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  buscaProduto(event) {
    this.produtoService.getListaProduto(event.query).subscribe(
      obj => {
        this.filtroProduto = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }  

  novoProduto() {
    this.display = true;
  }

  incluirProduto() {
    let detalhe: VendaOrcamentoDetalhe = new VendaOrcamentoDetalhe();
    detalhe.produto = this.produto;
    detalhe.quantidade = this.quantidade;
    detalhe.valorUnitario = this.produto.valorVenda;
    detalhe.valorTotal = this.quantidade * this.produto.valorVenda;

    this.orcamento.listaVendaOrcamentoDetalhe.push(detalhe);
    this.display = false;
  }

  cancelaInclusao() {
    this.display = false;
  }

  onSubmit(value) {
    let listaDetalhe: VendaOrcamentoDetalhe[] = this.orcamento.listaVendaOrcamentoDetalhe;
    this.orcamento = value as VendaOrcamentoCabecalho;
    this.orcamento.listaVendaOrcamentoDetalhe = listaDetalhe;
    this.salvar();
  }

}
