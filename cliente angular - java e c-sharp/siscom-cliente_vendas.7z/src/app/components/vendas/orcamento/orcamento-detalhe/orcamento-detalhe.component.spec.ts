import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrcamentoDetalheComponent } from './orcamento-detalhe.component';

describe('OrcamentoDetalheComponent', () => {
  let component: OrcamentoDetalheComponent;
  let fixture: ComponentFixture<OrcamentoDetalheComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrcamentoDetalheComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrcamentoDetalheComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
