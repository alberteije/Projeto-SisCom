import { Injectable } from "../../../node_modules/@angular/core";
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from "../../../node_modules/@angular/common/http";
import { Observable } from "../../../node_modules/rxjs";

import { Usuario } from './../classes/cadastros/usuario';

@Injectable()
export class JwtInterceptor implements HttpInterceptor {

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        let usuario: Usuario = JSON.parse(localStorage.getItem('usuarioSessao'));
        if (usuario && usuario.token) {
            req = req.clone({
                setHeaders: {
                    Authorization: 'Bearer ' + usuario.token
                }
            })
        }

        return next.handle(req);
    }
}