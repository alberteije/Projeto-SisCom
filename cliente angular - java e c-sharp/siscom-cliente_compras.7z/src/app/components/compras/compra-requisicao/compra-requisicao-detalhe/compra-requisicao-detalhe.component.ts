import { CompraReqCotacaoDetalhe } from './../../../../classes/compras/compra-req-cotacao-detalhe';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '../../../../../../node_modules/@angular/forms';
import { ColaboradorService } from '../../../../services/cadastros/colaborador.service';
import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { Location } from '../../../../../../node_modules/@angular/common';
import { ObjectUtils } from '../../../../../../node_modules/primeng/components/utils/objectutils';

import { Produto } from '../../../../classes/cadastros/produto';
import { ProdutoService } from './../../../../services/cadastros/produto.service';
import { CompraRequisicaoDetalhe } from './../../../../classes/compras/compra-requisicao-detalhe';
import { VariaveisGlobais } from './../../../../classes/variaveis-globais';
import { CompraTipoRequisicaoService } from './../../../../services/compras/compra-tipo-requisicao.service';
import { CompraRequisicaoService } from './../../../../services/compras/compra-requisicao.service';
import { Colaborador } from './../../../../classes/cadastros/colaborador';
import { CompraTipoRequisicao } from './../../../../classes/compras/compra-tipo-requisicao';
import { CompraRequisicao } from './../../../../classes/compras/compra-requisicao';

@Component({
  selector: 'app-compra-requisicao-detalhe',
  templateUrl: './compra-requisicao-detalhe.component.html',
  styleUrls: ['./compra-requisicao-detalhe.component.css']
})
export class CompraRequisicaoDetalheComponent implements OnInit {

  compraRequisicao: CompraRequisicao;
  filtroTipoRequisicao: CompraTipoRequisicao[];
  filtroColaborador: Colaborador[];
  userform: FormGroup;

  cols: any[];
  detalheSelecionado: CompraRequisicaoDetalhe;
  display: boolean = false;
  filtroProduto: Produto[];
  indiceSelecionado: number;

  constructor(private compraRequisicaoService: CompraRequisicaoService,
    private tipoRequisicaoService: CompraTipoRequisicaoService,
    private colaboradorService: ColaboradorService,
    private produtoService: ProdutoService,
    private route: ActivatedRoute,
    private location: Location,
    private router: Router,
    private global: VariaveisGlobais,
    private fb: FormBuilder,
    private objectUtils: ObjectUtils) { }

  ngOnInit() {
    this.userform = this.fb.group({
      'id': new FormControl(''),
      'compraTipoRequisicao': new FormControl('', Validators.required),
      'colaborador': new FormControl('', Validators.required),
      'dataRequisicao': new FormControl('', Validators.required)
    });

    this.cols = [
      { field: 'produto.nome', header: 'Produto' },
      { field: 'quantidade', header: 'Qtde' },
      { field: 'quantidadeCotada', header: 'Qtde Cotada' },
      { field: 'itemCotado', header: 'Item Cotado' }
    ];

    this.global.tituloJanela = "Detalhe Compra Requisicao";
    this.compraRequisicao = new CompraRequisicao();
    this.detalheSelecionado = new CompraRequisicaoDetalhe();

    if (this.router.url !== '/compra-requisicao/novo') {
      let id = this.route.snapshot.paramMap.get('id');
      this.compraRequisicaoService.getCompraRequisicao(parseInt(id, 0)).subscribe(
        obj => {
          this.compraRequisicao = obj;
          this.userform.patchValue(this.compraRequisicao);
        },
        error => {
          this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
        }
      );
    }
  }

  resolveFieldData(data, field) {
    return this.objectUtils.resolveFieldData(data, field);
  }

  retornar() {
    this.location.back();
  }

  salvar() {
    this.compraRequisicaoService.salvar(this.compraRequisicao).subscribe(
      obj => {
        this.compraRequisicao = obj;
        this.global.mostraMensagem(this.global.info, "Confirmação", 'Registro salvo com sucesso');
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  buscaTipoRequisicao(event) {
    this.tipoRequisicaoService.getListaCompraTipoRequisicao(event.query).subscribe(
      obj => {
        this.filtroTipoRequisicao = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  buscaColaborador(event) {
    this.colaboradorService.getListaColaboradores(event.query).subscribe(
      obj => {
        this.filtroColaborador = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  buscaProduto(event) {
    this.produtoService.getListaProduto(event.query).subscribe(
      obj => {
        this.filtroProduto = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  onSubmit(value) {
    let listaDetalhe: CompraRequisicaoDetalhe[] = this.compraRequisicao.listaCompraRequisicaoDetalhe;
    this.compraRequisicao = value as CompraRequisicao;
    this.compraRequisicao.listaCompraRequisicaoDetalhe = listaDetalhe;
    this.salvar();
  }

  onRowSelect(event) {
    this.indiceSelecionado = event.index;
  }

  novoDetalhe() {
    this.detalheSelecionado = new CompraRequisicaoDetalhe();
    this.display = true;
  }

  editarDetalhe() {
    this.display = true;
  }

  cancelaInclusao() {
    this.display = false;
  }

  incluirProduto() {
    if (this.detalheSelecionado.id == null) {
      this.compraRequisicao.listaCompraRequisicaoDetalhe.push(this.detalheSelecionado);
    } else {
      this.compraRequisicao.listaCompraRequisicaoDetalhe[this.indiceSelecionado] = this.detalheSelecionado;
    }
    
    this.display = false;
  }

  excluirProduto() {
    this.compraRequisicao.listaCompraRequisicaoDetalhe.splice(this.indiceSelecionado, 1);
  }

}
