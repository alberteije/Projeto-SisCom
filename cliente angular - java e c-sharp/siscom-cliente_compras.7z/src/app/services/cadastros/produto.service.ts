import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';
import { environment } from './../../../environments/environment';

import { Produto } from './../../classes/cadastros/produto';

@Injectable({
  providedIn: 'root'
})
export class ProdutoService {

  private url = environment.urlBaseServidor + 'produto/';

  constructor(private http: HttpClient) {  }

  getProdutos(): Observable<Produto[]> {
    return this.http.get<Produto[]>(this.url);
  }

  getListaProduto(nome: string): Observable<Produto[]> {
    return this.http.get<Produto[]>(this.url + 'lista/' + nome);
  }

  getProduto(id: number): Observable<Produto> {
    return this.http.get<Produto>(this.url + id);
  }

  salvar(setor: Produto): Observable<Produto> {
    return this.http.post<Produto>(this.url, setor, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
