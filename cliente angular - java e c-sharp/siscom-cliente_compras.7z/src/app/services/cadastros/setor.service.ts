import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';

import { Setor } from './../../classes/cadastros/setor';
import { environment } from './../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SetorService {

  private url = environment.urlBaseServidor + 'setor/';

  constructor(private http: HttpClient) {  }

  getSetors(): Observable<Setor[]> {
    return this.http.get<Setor[]>(this.url);
  }

  getListaSetor(nome: string): Observable<Setor[]> {
    return this.http.get<Setor[]>(this.url + 'lista/' + nome);
  }

  getSetor(id: number): Observable<Setor> {
    return this.http.get<Setor>(this.url + id);
  }

  salvar(setor: Setor): Observable<Setor> {
    return this.http.post<Setor>(this.url, setor, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
