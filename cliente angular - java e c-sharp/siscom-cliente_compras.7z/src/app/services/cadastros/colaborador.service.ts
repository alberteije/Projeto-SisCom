import { Injectable } from '@angular/core';
import { environment } from './../../../environments/environment';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';

import { Colaborador } from './../../classes/cadastros/colaborador';

@Injectable({
  providedIn: 'root'
})
export class ColaboradorService {

  private url = environment.urlBaseServidor + 'colaborador/';

  constructor(private http: HttpClient) {  }

  getColaboradores(): Observable<Colaborador[]> {
    return this.http.get<Colaborador[]>(this.url);
  }

  getListaColaboradores(nome: String): Observable<Colaborador[]> {
    return this.http.get<Colaborador[]>(this.url + 'lista/' + nome);
  }

  getColaborador(id: number): Observable<Colaborador> {
    return this.http.get<Colaborador>(this.url + id);
  }

  salvar(Colaborador: Colaborador): Observable<Colaborador> {
    return this.http.post<Colaborador>(this.url, Colaborador, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
