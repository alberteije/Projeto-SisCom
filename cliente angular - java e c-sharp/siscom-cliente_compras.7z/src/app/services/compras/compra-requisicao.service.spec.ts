import { TestBed, inject } from '@angular/core/testing';

import { CompraRequisicaoService } from './compra-requisicao.service';

describe('CompraRequisicaoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CompraRequisicaoService]
    });
  });

  it('should be created', inject([CompraRequisicaoService], (service: CompraRequisicaoService) => {
    expect(service).toBeTruthy();
  }));
});
