import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';
import { environment } from './../../../environments/environment';

import { CompraRequisicao } from './../../classes/compras/compra-requisicao';

@Injectable({
  providedIn: 'root'
})
export class CompraRequisicaoService {

  private url = environment.urlBaseServidor + 'compra/requisicao/';

  constructor(private http: HttpClient) {  }

  getListaCompraRequisicao(): Observable<CompraRequisicao[]> {
    return this.http.get<CompraRequisicao[]>(this.url);
  }

  getCompraRequisicao(id: number): Observable<CompraRequisicao> {
    return this.http.get<CompraRequisicao>(this.url + id);
  }

  salvar(compraRequisicao: CompraRequisicao): Observable<CompraRequisicao> {
    return this.http.post<CompraRequisicao>(this.url, compraRequisicao, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }
}
