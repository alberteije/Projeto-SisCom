export class Setor {
	id: number;
	nome: string;
	descricao: string;
}
