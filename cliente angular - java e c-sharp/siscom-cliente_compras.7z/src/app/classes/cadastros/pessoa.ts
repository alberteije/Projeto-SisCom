export class Pessoa {
	id: number;
	nome: string;
	tipo: string;
	email: string;
	site: string;
	cliente: string;
	fornecedor: string;
	colaborador: string;
	transportadora: string;
}
