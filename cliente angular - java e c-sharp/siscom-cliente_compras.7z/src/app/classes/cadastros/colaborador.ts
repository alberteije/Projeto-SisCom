import { Pessoa } from './pessoa';
import { TipoColaborador } from './tipo-colaborador';
import { Cargo } from './cargo';
import { Setor } from './setor';

export class Colaborador {
	id: number;
	pessoa: Pessoa;
	tipoColaborador: TipoColaborador;
	cargo: Cargo;
	setor: Setor;
	matricula: string;
	foto34: string;
	dataCadastro: string;
	dataAdmissao: string;
	pagamentoForma: string;
	pagamentoBanco: string;
	pagamentoAgencia: string;
	pagamentoAgenciaDigito: string;
	pagamentoConta: string;
	pagamentoContaDigito: string;
	ctpsNumero: string;
	ctpsSerie: string;
	ctpsDataExpedicao: string;
	ctpsUf: string;
	observacao: string;
	dataDemissao: string;
}
