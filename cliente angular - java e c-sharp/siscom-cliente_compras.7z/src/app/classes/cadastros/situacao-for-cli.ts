export class SituacaoForCli {
	id: number;
	nome: string;
	descricao: string;
}
