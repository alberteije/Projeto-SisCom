export class CompraTipoRequisicao {
	id: number;
	codigo: string;
	nome: string;
	descricao: string;
}
