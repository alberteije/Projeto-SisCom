import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '../../node_modules/@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { CargoComponent } from './components/cadastros/cargo/cargo.component';

import { AppComponent } from './app.component';
import { ToolbarModule } from 'primeng/toolbar';
import { AccordionModule } from 'primeng/accordion';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { AppRoutingModule } from './/app-routing.module';
import { CargoDetalheComponent } from './components/cadastros/cargo/cargo-detalhe/cargo-detalhe.component';
import { InputTextModule } from 'primeng/inputtext';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { GrowlModule } from 'primeng/growl';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { PasswordModule } from 'primeng/password';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { FileUploadModule } from 'primeng/fileupload';
import { CalendarModule } from 'primeng/calendar';
import { DialogModule } from 'primeng/dialog';
import { SpinnerModule } from 'primeng/spinner';
import { DropdownModule } from 'primeng/dropdown';
import { InputMaskModule } from 'primeng/inputmask';

import { NaoEncontradoComponent } from './components/nao-encontrado/nao-encontrado.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { JwtInterceptor } from './interceptor/jwt-interceptor';
import { ColaboradorComponent } from './components/cadastros/colaborador/colaborador.component';
import { ColaboradorDetalheComponent } from './components/cadastros/colaborador/colaborador-detalhe/colaborador-detalhe.component';
import { ObjectUtils } from '../../node_modules/primeng/components/utils/objectutils';
import { CompraRequisicaoComponent } from './components/compras/compra-requisicao/compra-requisicao.component';
import { CompraRequisicaoDetalheComponent } from './components/compras/compra-requisicao/compra-requisicao-detalhe/compra-requisicao-detalhe.component';
import { CompraCotacaoComponent } from './components/compras/compra-cotacao/compra-cotacao.component';
import { CompraCotacaoDetalheComponent } from './components/compras/compra-cotacao/compra-cotacao-detalhe/compra-cotacao-detalhe.component';
import { OrcamentoComponent } from './components/vendas/orcamento/orcamento.component';
import { OrcamentoDetalheComponent } from './components/vendas/orcamento/orcamento-detalhe/orcamento-detalhe.component';
import { ReajusteComponent } from './components/estoque/reajuste/reajuste.component';
import { ReajusteDetalheComponent } from './components/estoque/reajuste/reajuste-detalhe/reajuste-detalhe.component';
import { ContagemComponent } from './components/estoque/contagem/contagem.component';
import { ContagemDetalheComponent } from './components/estoque/contagem/contagem-detalhe/contagem-detalhe.component';
import { LancamentoPagarComponent } from './components/financeiro/lancamento-pagar/lancamento-pagar.component';
import { LancamentoPagarDetalheComponent } from './components/financeiro/lancamento-pagar/lancamento-pagar-detalhe/lancamento-pagar-detalhe.component';
import { ParcelaPagamentoComponent } from './components/financeiro/parcela-pagamento/parcela-pagamento.component';
import { ParcelaPagamentoDetalheComponent } from './components/financeiro/parcela-pagamento/parcela-pagamento-detalhe/parcela-pagamento-detalhe.component';
import { EmissaoChequeComponent } from './components/financeiro/emissao-cheque/emissao-cheque.component';
import { EmissaoChequeDetalheComponent } from './components/financeiro/emissao-cheque/emissao-cheque-detalhe/emissao-cheque-detalhe.component';
import { ExtratoComponent } from './components/financeiro/extrato/extrato.component';
import { ExtratoDetalheComponent } from './components/financeiro/extrato/extrato-detalhe/extrato-detalhe.component';

@NgModule({
  declarations: [
    AppComponent,
    CargoComponent,
    CargoDetalheComponent,
    NaoEncontradoComponent,
    HomeComponent,
    LoginComponent,
    ColaboradorComponent,
    ColaboradorDetalheComponent,
    CompraRequisicaoComponent,
    CompraRequisicaoDetalheComponent,
    CompraCotacaoComponent,
    CompraCotacaoDetalheComponent,
    OrcamentoComponent,
    OrcamentoDetalheComponent,
    ReajusteComponent,
    ReajusteDetalheComponent,
    ContagemComponent,
    ContagemDetalheComponent,
    LancamentoPagarComponent,
    LancamentoPagarDetalheComponent,
    ParcelaPagamentoComponent,
    ParcelaPagamentoDetalheComponent,
    EmissaoChequeComponent,
    EmissaoChequeDetalheComponent,
    ExtratoComponent,
    ExtratoDetalheComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    ToolbarModule,
    AccordionModule,
    TableModule,
    ButtonModule,
    AppRoutingModule,
    InputTextModule,
    InputTextareaModule,
    FormsModule,
    ReactiveFormsModule,
    GrowlModule,
    ConfirmDialogModule,
    PasswordModule,
    HttpClientModule,
    AutoCompleteModule,
    FileUploadModule,
    CalendarModule,
    DialogModule,
    SpinnerModule,
    DropdownModule,
    InputMaskModule
  ],
  providers: [ConfirmationService,
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    ObjectUtils
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
