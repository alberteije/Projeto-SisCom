export class Papel {
    id: number;
    nome: string;
    descricao: string;
    acessoCompleto: string;
}