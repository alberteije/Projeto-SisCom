export class ProdutoGrupo {
	id: number;
	nome: string;
	descricao: string;
}
