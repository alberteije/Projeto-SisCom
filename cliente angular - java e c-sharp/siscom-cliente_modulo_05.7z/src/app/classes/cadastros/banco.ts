export class Banco {
	id: number;
	codigo: string;
	nome: string;
	url: string;
}
