export class FinTipoPagamento {
	id: number;
	tipo: string;
	descricao: string;
}
