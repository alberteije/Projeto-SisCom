export class FinTipoRecebimento {
	id: number;
	tipo: string;
	descricao: string;
}
