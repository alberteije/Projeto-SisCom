export class FinStatusParcela {
	id: number;
	situacao: string;
	descricao: string;
	procedimento: string;
}
