import { CompraFornecedorCotacao } from './compra-fornecedor-cotacao';
import { Produto } from '../cadastros/produto';

export class CompraCotacaoDetalhe {
	id: number;
	compraFornecedorCotacao: CompraFornecedorCotacao;
	produto: Produto;
	quantidade: number;
	quantidadePedida: number;
	valorUnitario: number;
	valorSubtotal: number;
	taxaDesconto: number;
	valorDesconto: number;
	valorTotal: number;
}
