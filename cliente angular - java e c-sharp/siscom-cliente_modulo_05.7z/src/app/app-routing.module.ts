import { ExtratoDetalheComponent } from './components/financeiro/extrato/extrato-detalhe/extrato-detalhe.component';
import { ExtratoComponent } from './components/financeiro/extrato/extrato.component';
import { EmissaoChequeDetalheComponent } from './components/financeiro/emissao-cheque/emissao-cheque-detalhe/emissao-cheque-detalhe.component';
import { EmissaoChequeComponent } from './components/financeiro/emissao-cheque/emissao-cheque.component';
import { LancamentoPagarDetalheComponent } from './components/financeiro/lancamento-pagar/lancamento-pagar-detalhe/lancamento-pagar-detalhe.component';
import { LancamentoPagarComponent } from './components/financeiro/lancamento-pagar/lancamento-pagar.component';
import { ContagemDetalheComponent } from './components/estoque/contagem/contagem-detalhe/contagem-detalhe.component';
import { ReajusteDetalheComponent } from './components/estoque/reajuste/reajuste-detalhe/reajuste-detalhe.component';
import { ReajusteComponent } from './components/estoque/reajuste/reajuste.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from './components/login/login.component';
import { CargoComponent } from './components/cadastros/cargo/cargo.component';
import { CargoDetalheComponent } from './components/cadastros/cargo/cargo-detalhe/cargo-detalhe.component';
import { ColaboradorDetalheComponent } from './components/cadastros/colaborador/colaborador-detalhe/colaborador-detalhe.component';
import { ColaboradorComponent } from './components/cadastros/colaborador/colaborador.component';
import { CompraRequisicaoDetalheComponent } from './components/compras/compra-requisicao/compra-requisicao-detalhe/compra-requisicao-detalhe.component';
import { CompraRequisicaoComponent } from './components/compras/compra-requisicao/compra-requisicao.component';
import { CompraCotacaoDetalheComponent } from './components/compras/compra-cotacao/compra-cotacao-detalhe/compra-cotacao-detalhe.component';
import { CompraCotacaoComponent } from './components/compras/compra-cotacao/compra-cotacao.component';
import { OrcamentoDetalheComponent } from './components/vendas/orcamento/orcamento-detalhe/orcamento-detalhe.component';
import { OrcamentoComponent } from './components/vendas/orcamento/orcamento.component';

import { NaoEncontradoComponent } from './components/nao-encontrado/nao-encontrado.component';
import { HomeComponent } from './components/home/home.component';
import { AuthGuardService } from './auth-guard.service';
import { ContagemComponent } from './components/estoque/contagem/contagem.component';
import { ParcelaPagamentoComponent } from './components/financeiro/parcela-pagamento/parcela-pagamento.component';
import { ParcelaPagamentoDetalheComponent } from './components/financeiro/parcela-pagamento/parcela-pagamento-detalhe/parcela-pagamento-detalhe.component';

const routes: Routes = [
  {
    path: '', canActivate: [AuthGuardService],
    children: [
      { path: '', component: HomeComponent },
      { path: 'cargo', component: CargoComponent },
      { path: 'cargo/novo', component: CargoDetalheComponent },
      { path: 'cargo/:id', component: CargoDetalheComponent },
      { path: 'colaborador', component: ColaboradorComponent },
      { path: 'colaborador/novo', component: ColaboradorDetalheComponent },
      { path: 'colaborador/:id', component: ColaboradorDetalheComponent },
      { path: 'compra-requisicao', component: CompraRequisicaoComponent },
      { path: 'compra-requisicao/novo', component: CompraRequisicaoDetalheComponent },
      { path: 'compra-requisicao/:id', component: CompraRequisicaoDetalheComponent },
      { path: 'compra-cotacao', component: CompraCotacaoComponent },
      { path: 'compra-cotacao/novo', component: CompraCotacaoDetalheComponent },
      { path: 'compra-cotacao/:id', component: CompraCotacaoDetalheComponent },
      { path: 'venda-orcamento', component: OrcamentoComponent },
      { path: 'venda-orcamento/novo', component: OrcamentoDetalheComponent },
      { path: 'venda-orcamento/:id', component: OrcamentoDetalheComponent },
      { path: 'estoque-reajuste', component: ReajusteComponent },
      { path: 'estoque-reajuste/novo', component: ReajusteDetalheComponent },
      { path: 'estoque-reajuste/:id', component: ReajusteDetalheComponent },
      { path: 'estoque-contagem', component: ContagemComponent },
      { path: 'estoque-contagem/novo', component: ContagemDetalheComponent },
      { path: 'estoque-contagem/:id', component: ContagemDetalheComponent },
      { path: 'lancamento-pagar', component: LancamentoPagarComponent },
      { path: 'lancamento-pagar/novo', component: LancamentoPagarDetalheComponent },
      { path: 'lancamento-pagar/:id', component: LancamentoPagarDetalheComponent },
      { path: 'parcela-pagamento', component: ParcelaPagamentoComponent },
      { path: 'parcela-pagamento/novo', component: ParcelaPagamentoDetalheComponent },
      { path: 'parcela-pagamento/:id', component: ParcelaPagamentoDetalheComponent },
      { path: 'emissao-cheque', component: EmissaoChequeComponent },
      { path: 'emissao-cheque/novo', component: EmissaoChequeDetalheComponent },
      { path: 'emissao-cheque/:id', component: EmissaoChequeDetalheComponent },
      { path: 'extrato', component: ExtratoComponent },
      { path: 'extrato/novo', component: ExtratoDetalheComponent },
      { path: 'extrato/:id', component: ExtratoDetalheComponent },
      { path: 'nao-encontrado', component: NaoEncontradoComponent }
    ]
  },
  { path: 'login', component: LoginComponent }
];

@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forRoot(routes)]
})
export class AppRoutingModule { }
