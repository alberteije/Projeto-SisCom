import { TestBed, inject } from '@angular/core/testing';

import { VendaCabecalhoService } from './venda-cabecalho.service';

describe('VendaCabecalhoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [VendaCabecalhoService]
    });
  });

  it('should be created', inject([VendaCabecalhoService], (service: VendaCabecalhoService) => {
    expect(service).toBeTruthy();
  }));
});
