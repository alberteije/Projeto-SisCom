import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';
import { VendaCabecalho } from '../../classes/vendas/venda-cabecalho';

@Injectable({
  providedIn: 'root'
})
export class VendaCabecalhoService {

  private url = environment.urlBaseServidor + 'vendas/cabecalho/';

  constructor(private http: HttpClient) {  }

  getListaVendaCabecalho(): Observable<VendaCabecalho[]> {
      return this.http.get<VendaCabecalho[]>(this.url);
  }

  getVendaCabecalho(id: number): Observable<VendaCabecalho> {
    return this.http.get<VendaCabecalho>(this.url + id);
  }

  salvar(vendaCabecalho: VendaCabecalho): Observable<VendaCabecalho> {
    return this.http.post<VendaCabecalho>(this.url, vendaCabecalho, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
