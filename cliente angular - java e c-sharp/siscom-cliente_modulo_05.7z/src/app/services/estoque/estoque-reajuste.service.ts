import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';
import { environment } from './../../../environments/environment';

import { EstoqueReajusteCabecalho } from './../../classes/estoque/estoque-reajuste-cabecalho';

@Injectable({
  providedIn: 'root'
})
export class EstoqueReajusteService {

  private url = environment.urlBaseServidor + 'estoque/reajuste/';

  constructor(private http: HttpClient) {  }

  getListaEstoqueReajusteCabecalho(): Observable<EstoqueReajusteCabecalho[]> {
    return this.http.get<EstoqueReajusteCabecalho[]>(this.url);
  }

  getEstoqueReajusteCabecalho(id: number): Observable<EstoqueReajusteCabecalho> {
    return this.http.get<EstoqueReajusteCabecalho>(this.url + id);
  }

  salvar(estoqueReajusteCabecalho: EstoqueReajusteCabecalho): Observable<EstoqueReajusteCabecalho> {
    return this.http.post<EstoqueReajusteCabecalho>(this.url, estoqueReajusteCabecalho, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
