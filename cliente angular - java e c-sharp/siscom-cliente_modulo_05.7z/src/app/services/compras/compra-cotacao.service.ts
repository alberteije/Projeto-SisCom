import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';
import { environment } from './../../../environments/environment';

import { CompraCotacao } from './../../classes/compras/compra-cotacao';

@Injectable({
  providedIn: 'root'
})
export class CompraCotacaoService {

  private url = environment.urlBaseServidor + 'compra/cotacao/';

  constructor(private http: HttpClient) {  }

  getListaCompraCotacao(): Observable<CompraCotacao[]> {
    return this.http.get<CompraCotacao[]>(this.url);
  }

  getCompraCotacao(id: number): Observable<CompraCotacao> {
    return this.http.get<CompraCotacao>(this.url + id);
  }

  salvar(compraCotacao: CompraCotacao): Observable<CompraCotacao> {
    return this.http.post<CompraCotacao>(this.url, compraCotacao, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
