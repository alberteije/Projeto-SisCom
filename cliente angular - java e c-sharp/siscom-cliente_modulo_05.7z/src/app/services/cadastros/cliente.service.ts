import { Cliente } from './../../classes/cadastros/cliente';
import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class ClienteService {

  private url = environment.urlBaseServidor + 'cliente/';

  constructor(private http: HttpClient) {  }

  getClientes(): Observable<Cliente[]> {
    return this.http.get<Cliente[]>(this.url);
  }

  getListaCliente(nome: string): Observable<Cliente[]> {
    return this.http.get<Cliente[]>(this.url + 'lista/' + nome);
  }

  getCliente(id: number): Observable<Cliente> {
    return this.http.get<Cliente>(this.url + id);
  }

  salvar(cliente: Cliente): Observable<Cliente> {
    return this.http.post<Cliente>(this.url, cliente, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
