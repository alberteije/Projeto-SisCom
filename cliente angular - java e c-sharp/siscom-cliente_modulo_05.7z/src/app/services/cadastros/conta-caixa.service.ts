import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';
import { environment } from './../../../environments/environment';

import { ContaCaixa } from './../../classes/cadastros/conta-caixa';

@Injectable({
  providedIn: 'root'
})
export class ContaCaixaService {

  private url = environment.urlBaseServidor + 'conta-caixa/';

  constructor(private http: HttpClient) { }

  getListaContaCaixa(nome?: String): Observable<ContaCaixa[]> {
    if (nome == null) {
      return this.http.get<ContaCaixa[]>(this.url);
    } else {
      return this.http.get<ContaCaixa[]>(this.url + 'lista/' + nome);
    }
  }

  getContaCaixa(id: number): Observable<ContaCaixa> {
    return this.http.get<ContaCaixa>(this.url + id);
  }

  salvar(ContaCaixa: ContaCaixa): Observable<ContaCaixa> {
    return this.http.post<ContaCaixa>(this.url, ContaCaixa, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
