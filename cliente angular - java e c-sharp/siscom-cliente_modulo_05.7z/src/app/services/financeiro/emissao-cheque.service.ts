import { FinChequeEmitido } from './../../classes/financeiro/fin-cheque-emitido';
import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmissaoChequeService {

  private url = environment.urlBaseServidor + 'financeiro/emissao-cheque/';

  constructor(private http: HttpClient) { }

  getListaFinChequeEmitido(): Observable<FinChequeEmitido[]> {
      return this.http.get<FinChequeEmitido[]>(this.url);
  }

  getFinChequeEmitido(id: number): Observable<FinChequeEmitido> {
    return this.http.get<FinChequeEmitido>(this.url + id);
  }

  salvar(chequeEmitido: FinChequeEmitido): Observable<FinChequeEmitido> {
    return this.http.post<FinChequeEmitido>(this.url, chequeEmitido, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
