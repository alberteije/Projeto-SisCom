import { FinLancamentoPagar } from './../../classes/financeiro/fin-lancamento-pagar';
import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class LancamentoPagarService {

  private url = environment.urlBaseServidor + 'financeiro/lancamento-pagar/';

  constructor(private http: HttpClient) { }

  getListaFinLancamentoPagar(): Observable<FinLancamentoPagar[]> {
      return this.http.get<FinLancamentoPagar[]>(this.url);
  }

  getFinLancamentoPagar(id: number): Observable<FinLancamentoPagar> {
    return this.http.get<FinLancamentoPagar>(this.url + id);
  }

  salvar(finLancamentoPagar: FinLancamentoPagar): Observable<FinLancamentoPagar> {
    return this.http.post<FinLancamentoPagar>(this.url, finLancamentoPagar, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
