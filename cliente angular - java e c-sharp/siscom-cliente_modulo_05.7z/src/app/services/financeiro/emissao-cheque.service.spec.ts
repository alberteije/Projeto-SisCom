import { TestBed, inject } from '@angular/core/testing';

import { EmissaoChequeService } from './emissao-cheque.service';

describe('EmissaoChequeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EmissaoChequeService]
    });
  });

  it('should be created', inject([EmissaoChequeService], (service: EmissaoChequeService) => {
    expect(service).toBeTruthy();
  }));
});
