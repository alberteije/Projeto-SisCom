import { TestBed, inject } from '@angular/core/testing';

import { StatusParcelaService } from './status-parcela.service';

describe('StatusParcelaService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [StatusParcelaService]
    });
  });

  it('should be created', inject([StatusParcelaService], (service: StatusParcelaService) => {
    expect(service).toBeTruthy();
  }));
});
