import { FinExtratoContaBanco } from './../../classes/financeiro/fin-extrato-conta-banco';
import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class ExtratoService {
  
  private url = environment.urlBaseServidor + 'financeiro/extrato-conta-banco/';

  urlUpload = this.url + 'upload/';//upload/{idContaCaixa}

  constructor(private http: HttpClient) { }

  getListaFinExtratoContaBanco(idContaCaixa: number, mesAno: String): Observable<FinExtratoContaBanco[]> {
      return this.http.get<FinExtratoContaBanco[]>(this.url + 'lista/' + idContaCaixa + '/' + mesAno);
  }

}
