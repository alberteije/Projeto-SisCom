import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';

import { FinTipoPagamento } from './../../classes/financeiro/fin-tipo-pagamento';

@Injectable({
  providedIn: 'root'
})
export class TipoPagamentoService {

  private url = environment.urlBaseServidor + 'financeiro/tipo-pagamento/';

  constructor(private http: HttpClient) { }

  getListaFinTipoPagamento(nome: String): Observable<FinTipoPagamento[]> {
    if (nome == null) {
      return this.http.get<FinTipoPagamento[]>(this.url);
    } else {
      return this.http.get<FinTipoPagamento[]>(this.url + 'lista/' + nome);
    }
  }

  getFinTipoPagamento(id: number): Observable<FinTipoPagamento> {
    return this.http.get<FinTipoPagamento>(this.url + id);
  }

  salvar(tipoPagamento: FinTipoPagamento): Observable<FinTipoPagamento> {
    return this.http.post<FinTipoPagamento>(this.url, tipoPagamento, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
