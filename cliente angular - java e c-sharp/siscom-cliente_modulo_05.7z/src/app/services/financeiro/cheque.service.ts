import { Cheque } from './../../classes/financeiro/cheque';
import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class ChequeService {

  private url = environment.urlBaseServidor + 'financeiro/cheque/';

  constructor(private http: HttpClient) { }

  getListaCheque(numero: number): Observable<Cheque[]> {
    if (numero == null) {
      return this.http.get<Cheque[]>(this.url);
    } else {
      return this.http.get<Cheque[]>(this.url + 'lista/' + numero);
    }
  }

  getCheque(id: number): Observable<Cheque> {
    return this.http.get<Cheque>(this.url + id);
  }

  salvar(cheque: Cheque): Observable<Cheque> {
    return this.http.post<Cheque>(this.url, cheque, environment.httpOptions);
  }

  excluir(id: number): Observable<{}> {
    return this.http.delete(this.url + id);
  }

}
