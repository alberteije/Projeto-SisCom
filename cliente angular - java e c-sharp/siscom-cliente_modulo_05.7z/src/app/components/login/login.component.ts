import { Component, OnInit } from '@angular/core';
import { Router } from '../../../../node_modules/@angular/router';

import { Usuario } from './../../classes/cadastros/usuario';
import { LoginService } from './../../services/login.service';
import { VariaveisGlobais } from '../../classes/variaveis-globais';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  usuario: Usuario;

  constructor(private loginService: LoginService,
    private global: VariaveisGlobais,
    private router: Router) { }

  ngOnInit() {
    this.usuario = new Usuario();
  }

  login() {
    this.loginService.login(this.usuario).subscribe(
      obj => {
        this.usuario = obj;
        this.router.navigate(['/']);
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  botaoDesabilitado() {
    return !(this.usuario.login && this.usuario.senha);
  }
}
