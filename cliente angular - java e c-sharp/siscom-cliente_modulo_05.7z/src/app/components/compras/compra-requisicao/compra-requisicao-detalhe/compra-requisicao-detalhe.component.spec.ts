import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompraRequisicaoDetalheComponent } from './compra-requisicao-detalhe.component';

describe('CompraRequisicaoDetalheComponent', () => {
  let component: CompraRequisicaoDetalheComponent;
  let fixture: ComponentFixture<CompraRequisicaoDetalheComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompraRequisicaoDetalheComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompraRequisicaoDetalheComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
