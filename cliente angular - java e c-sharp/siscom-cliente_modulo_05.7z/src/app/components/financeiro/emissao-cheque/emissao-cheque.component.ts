import { Cheque } from './../../../classes/financeiro/cheque';
import { ChequeService } from './../../../services/financeiro/cheque.service';
import { FinChequeEmitido } from './../../../classes/financeiro/fin-cheque-emitido';
import { VariaveisGlobais } from './../../../classes/variaveis-globais';
import { ParcelaPagamentoService } from './../../../services/financeiro/parcela-pagamento.service';
import { EmissaoChequeService } from './../../../services/financeiro/emissao-cheque.service';
import { FinParcelaPagar } from './../../../classes/financeiro/fin-parcela-pagar';
import { Component, OnInit } from '@angular/core';
import { ObjectUtils } from '../../../../../node_modules/primeng/components/utils/objectutils';

@Component({
  selector: 'app-emissao-cheque',
  templateUrl: './emissao-cheque.component.html',
  styleUrls: ['./emissao-cheque.component.css']
})
export class EmissaoChequeComponent implements OnInit {

  listaParcelaPagar: FinParcelaPagar[];
  cols: any[];
  parcelaPagarSelecionado: FinParcelaPagar[];
  botoesDesabilitados: boolean = true;
  display = false;
  chequeEmitido: FinChequeEmitido;
  filtroCheque: Cheque[];

  constructor(private parcelaPagamentoService: ParcelaPagamentoService,
    private emissaoChequeService: EmissaoChequeService,
    private chequeService: ChequeService,
    private global: VariaveisGlobais,
    private objectUtils: ObjectUtils) { }

  ngOnInit() {
    this.global.tituloJanela = "Emissão de Cheque";
    this.chequeEmitido = new FinChequeEmitido();
    this.carregaDados();

    this.cols = [
      { field: 'contaCaixa.nome', header: 'Conta Caixa' },
      { field: 'finStatusParcela.descricao', header: 'Status' },
      { field: 'valor', header: 'Valor' }
    ];
  }

  resolveFieldData(data, field) {
    return this.objectUtils.resolveFieldData(data, field);
  }

  private carregaDados() {
    this.parcelaPagamentoService.getListaFinParcelaPagar().subscribe(
      lista => {
        this.listaParcelaPagar = lista;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  onRowSelect(event) {
    if (this.parcelaPagarSelecionado.length > 0) {
      this.botoesDesabilitados = false;
    }
  }

  onRowUnselect(event) {
    if (this.parcelaPagarSelecionado.length <= 0) {
      this.botoesDesabilitados = true;
    }
  }

  buscaCheque(event) {
    this.chequeService.getListaCheque(event.query).subscribe(
      obj => {
        this.filtroCheque = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  iniciaEmissaoCheque() {
    this.display = true;
  }

  cancelaEmissao() {
    this.display = false;
  }

  emiteCheque() {
    this.chequeEmitido.listaFinParcelaPagar = this.parcelaPagarSelecionado;
    this.emissaoChequeService.salvar(this.chequeEmitido).subscribe(
      obj => {
        this.global.mostraMensagem(this.global.info, "Confirmação", 'Cheque emitido com sucesso.');
        this.display = false;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );    
  }
}
