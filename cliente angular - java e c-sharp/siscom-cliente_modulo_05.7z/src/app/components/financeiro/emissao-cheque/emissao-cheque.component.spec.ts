import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmissaoChequeComponent } from './emissao-cheque.component';

describe('EmissaoChequeComponent', () => {
  let component: EmissaoChequeComponent;
  let fixture: ComponentFixture<EmissaoChequeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmissaoChequeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmissaoChequeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
