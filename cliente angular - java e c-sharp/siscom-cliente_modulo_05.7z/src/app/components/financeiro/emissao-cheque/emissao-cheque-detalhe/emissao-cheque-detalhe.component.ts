import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emissao-cheque-detalhe',
  templateUrl: './emissao-cheque-detalhe.component.html',
  styleUrls: ['./emissao-cheque-detalhe.component.css']
})
export class EmissaoChequeDetalheComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
