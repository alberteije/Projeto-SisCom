import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmissaoChequeDetalheComponent } from './emissao-cheque-detalhe.component';

describe('EmissaoChequeDetalheComponent', () => {
  let component: EmissaoChequeDetalheComponent;
  let fixture: ComponentFixture<EmissaoChequeDetalheComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmissaoChequeDetalheComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmissaoChequeDetalheComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
