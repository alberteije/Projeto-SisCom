import { VariaveisGlobais } from './../../../classes/variaveis-globais';
import { ContaCaixa } from './../../../classes/cadastros/conta-caixa';
import { Component, OnInit } from '@angular/core';
import { ContaCaixaService } from '../../../services/cadastros/conta-caixa.service';
import { ObjectUtils } from '../../../../../node_modules/primeng/components/utils/objectutils';

@Component({
  selector: 'app-extrato',
  templateUrl: './extrato.component.html',
  styleUrls: ['./extrato.component.css']
})
export class ExtratoComponent implements OnInit {

  listaContaCaixa: ContaCaixa[];
  cols: any[];
  contaCaixaSelecionado: ContaCaixa;
  botoesDesabilitados: boolean = true;

  constructor(private contaCaixaService: ContaCaixaService,
    private global: VariaveisGlobais,
    private objectUtils: ObjectUtils) { }

  ngOnInit() {
    this.global.tituloJanela = "Conta Caixas";
    this.carregaDados();

    this.cols = [
      { field: 'nome', header: 'Nome' },
      { field: 'codigo', header: 'Código' }
    ];
  }

  resolveFieldData(data, field) {
    return this.objectUtils.resolveFieldData(data, field);
  }

  private carregaDados() {
    this.contaCaixaService.getListaContaCaixa().subscribe(
      lista => {
        this.listaContaCaixa = lista;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  onRowSelect(event) {
    this.botoesDesabilitados = false;
  }

  onRowUnselect(event) {
    this.botoesDesabilitados = true;
  }

  getIdContaCaixa() {
    return this.contaCaixaSelecionado == null ? null : this.contaCaixaSelecionado.id;
  }

}
