import { Usuario } from './../../../../classes/cadastros/usuario';
import { environment } from './../../../../../environments/environment';
import { FinExtratoContaBanco } from './../../../../classes/financeiro/fin-extrato-conta-banco';
import { VariaveisGlobais } from './../../../../classes/variaveis-globais';
import { ContaCaixaService } from './../../../../services/cadastros/conta-caixa.service';
import { ContaCaixa } from './../../../../classes/cadastros/conta-caixa';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { Location } from '../../../../../../node_modules/@angular/common';
import { FormBuilder } from '../../../../../../node_modules/@angular/forms';
import { ObjectUtils } from '../../../../../../node_modules/primeng/components/utils/objectutils';
import { ExtratoService } from '../../../../services/financeiro/extrato.service';

@Component({
  selector: 'app-extrato-detalhe',
  templateUrl: './extrato-detalhe.component.html',
  styleUrls: ['./extrato-detalhe.component.css']
})
export class ExtratoDetalheComponent implements OnInit {

  contaCaixa: ContaCaixa;
  listaExtrato: FinExtratoContaBanco[];
  mesAno: String;
  urlUpload: String;

  cols: any[];

  constructor(private contaCaixaService: ContaCaixaService,
    private extratoService: ExtratoService,
    private route: ActivatedRoute,
    private location: Location,
    private router: Router,
    private global: VariaveisGlobais,
    private fb: FormBuilder,
    private objectUtils: ObjectUtils) { }

  ngOnInit() {

    this.cols = [
      { field: 'mesAno', header: 'Período' },
      { field: 'dataMovimento', header: 'Data' },
      { field: 'numeroDocumento', header: 'Nr. Documento' },
      { field: 'valor', header: 'Valor' },
      { field: 'conciliado', header: 'Conciliado' }
    ];

    this.global.tituloJanela = "Extrato de Conta";
    this.contaCaixa = new ContaCaixa();

    let id = this.route.snapshot.paramMap.get('id');
    this.contaCaixaService.getContaCaixa(parseInt(id, 0)).subscribe(
      obj => {
        this.contaCaixa = obj;
        this.urlUpload = this.extratoService.urlUpload + this.contaCaixa.id;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  resolveFieldData(data, field) {
    return this.objectUtils.resolveFieldData(data, field);
  }

  retornar() {
    this.location.back();
  }

  carregaExtrato() {
    this.extratoService.getListaFinExtratoContaBanco(this.contaCaixa.id, this.mesAno).subscribe(
      obj => {
        this.listaExtrato = obj;
        if (this.listaExtrato.length == 0) {
          this.global.mostraMensagem(this.global.info, "Informação", 'Não foram localizados registros com os dados informados.');
        }
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  erroUpload(event) {
    const mensagem = JSON.parse(event.xhr.response).message;
    this.global.mostraMensagem(this.global.error, "Ocorreu um erro", mensagem);
  }

  onBeforeSend(event) {
    let usuario: Usuario = JSON.parse(localStorage.getItem('usuarioSessao'));
    event.xhr.setRequestHeader('Authorization', usuario.token);
  }

  onUpload(event) {
    this.global.mostraMensagem(this.global.info, "Confirmação", 'Upload realizado com sucesso');
  }

}
