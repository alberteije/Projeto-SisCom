import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParcelaPagamentoDetalheComponent } from './parcela-pagamento-detalhe.component';

describe('ParcelaPagamentoDetalheComponent', () => {
  let component: ParcelaPagamentoDetalheComponent;
  let fixture: ComponentFixture<ParcelaPagamentoDetalheComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParcelaPagamentoDetalheComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParcelaPagamentoDetalheComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
