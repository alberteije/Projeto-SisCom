import { VariaveisGlobais } from './../../../classes/variaveis-globais';
import { ConfirmationService } from 'primeng/api';
import { LancamentoPagarService } from './../../../services/financeiro/lancamento-pagar.service';
import { FinLancamentoPagar } from './../../../classes/financeiro/fin-lancamento-pagar';
import { Component, OnInit } from '@angular/core';
import { ObjectUtils } from '../../../../../node_modules/primeng/components/utils/objectutils';

@Component({
  selector: 'app-lancamento-pagar',
  templateUrl: './lancamento-pagar.component.html',
  styleUrls: ['./lancamento-pagar.component.css']
})
export class LancamentoPagarComponent implements OnInit {

  listaLancamentoPagar: FinLancamentoPagar[];
  cols: any[];
  lancamentoPagarSelecionado: FinLancamentoPagar;
  botoesDesabilitados: boolean = true;

  constructor(private lancamentoPagarService: LancamentoPagarService,
    private confirmationService: ConfirmationService,
    private global: VariaveisGlobais,
    private objectUtils: ObjectUtils) { }

  ngOnInit() {
    this.global.tituloJanela = "Lançamentos a Pagar";
    this.carregaDados();

    this.cols = [
      { field: 'fornecedor.pessoa.nome', header: 'Fornecedor' },
      { field: 'finNaturezaFinanceira.descricao', header: 'Natureza Financeira' },
      { field: 'finDocumentoOrigem.siglaDocumento', header: 'Documento Origem' },
      { field: 'valorTotal', header: 'Valor' }
    ];
  }

  resolveFieldData(data, field) {
    return this.objectUtils.resolveFieldData(data, field);
  }

  private carregaDados() {
    this.lancamentoPagarService.getListaFinLancamentoPagar().subscribe(
      lista => {
        this.listaLancamentoPagar = lista;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  onRowSelect(event) {
    this.botoesDesabilitados = false;
  }

  onRowUnselect(event) {
    this.botoesDesabilitados = true;
  }

  getIdLancamentoPagar() {
    return this.lancamentoPagarSelecionado == null ? null : this.lancamentoPagarSelecionado.id;
  }

  excluir() {
    this.confirmationService.confirm({
      message: 'Excluir o registro selecionado?',
      header: 'Confirmação',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.lancamentoPagarService.excluir(this.lancamentoPagarSelecionado.id).subscribe(
          _ => {
            this.carregaDados();
            this.botoesDesabilitados = true;
            this.global.mostraMensagem(this.global.info, "Confirmação", 'Registro excluído com sucesso');
          },
          error => {
            this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
          }
        );
      },
      reject: () => {
        //this.msgs = [{ severity: 'info', summary: 'Rejected', detail: 'You have rejected' }];
      }
    });
  }

}
