import { ContaCaixa } from './../../../../classes/cadastros/conta-caixa';
import { ContaCaixaService } from './../../../../services/cadastros/conta-caixa.service';
import { FinParcelaPagar } from './../../../../classes/financeiro/fin-parcela-pagar';
import { VariaveisGlobais } from './../../../../classes/variaveis-globais';
import { FornecedorService } from './../../../../services/cadastros/fornecedor.service';
import { DocumentoOrigemService } from './../../../../services/financeiro/documento-origem.service';
import { NaturezaFinanceiraService } from './../../../../services/financeiro/natureza-financeira.service';
import { LancamentoPagarService } from './../../../../services/financeiro/lancamento-pagar.service';
import { FinNaturezaFinanceira } from './../../../../classes/financeiro/fin-natureza-financeira';
import { Fornecedor } from './../../../../classes/cadastros/fornecedor';
import { FinDocumentoOrigem } from './../../../../classes/financeiro/fin-documento-origem';
import { FinLancamentoPagar } from './../../../../classes/financeiro/fin-lancamento-pagar';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '../../../../../../node_modules/@angular/forms';
import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { Location } from '../../../../../../node_modules/@angular/common';
import { ObjectUtils } from '../../../../../../node_modules/primeng/components/utils/objectutils';

@Component({
  selector: 'app-lancamento-pagar-detalhe',
  templateUrl: './lancamento-pagar-detalhe.component.html',
  styleUrls: ['./lancamento-pagar-detalhe.component.css']
})
export class LancamentoPagarDetalheComponent implements OnInit {

  lancamentoPagar: FinLancamentoPagar;
  filtroNaturezaFinanceira: FinNaturezaFinanceira[];
  filtroDocumentoOrigem: FinDocumentoOrigem[];
  filtroFornecedor: Fornecedor[];
  filtroContaCaixa: ContaCaixa[];
  userform: FormGroup;

  cols: any[];

  constructor(private lancamentoPagarService: LancamentoPagarService,
    private naturezaFinananceiraService: NaturezaFinanceiraService,
    private documentoOrigemService: DocumentoOrigemService,
    private fornecedorService: FornecedorService,
    private contaCaixaService: ContaCaixaService,
    private route: ActivatedRoute,
    private location: Location,
    private router: Router,
    private global: VariaveisGlobais,
    private fb: FormBuilder,
    private objectUtils: ObjectUtils) { }

  ngOnInit() {
    this.userform = this.fb.group({
      'id': new FormControl(''),
      'finNaturezaFinanceira': new FormControl('', Validators.required),
      'finDocumentoOrigem': new FormControl('', Validators.required),
      'fornecedor': new FormControl('', Validators.required),
      'quantidadeParcela': new FormControl('', Validators.required),
      'valorTotal': new FormControl('', Validators.required),
      'primeiroVencimento': new FormControl('', Validators.required),
      'intervaloEntreParcelas': new FormControl('', Validators.required),
      'contaCaixa': new FormControl('', Validators.required)
    });

    this.cols = [
      { field: 'contaCaixa.nome', header: 'Conta Caixa' },
      { field: 'finStatusParcela.descricao', header: 'Status' },
      { field: 'numeroParcela', header: 'Nr. Parcela' },
      { field: 'dataEmissao', header: 'Data Emissão' },
      { field: 'dataVencimento', header: 'Vencimento' },
      { field: 'valor', header: 'Valor' }
    ];

    this.global.tituloJanela = "Detalhe Lançamento a Pagar";
    this.lancamentoPagar = new FinLancamentoPagar();

    if (this.router.url !== '/lancamento-pagar/novo') {
      let id = this.route.snapshot.paramMap.get('id');
      this.lancamentoPagarService.getFinLancamentoPagar(parseInt(id, 0)).subscribe(
        obj => {
          this.lancamentoPagar = obj;
          console.log(this.lancamentoPagar);
          this.userform.patchValue(this.lancamentoPagar);
        },
        error => {
          this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
        }
      );
    }
  }

  resolveFieldData(data, field) {
    return this.objectUtils.resolveFieldData(data, field);
  }

  retornar() {
    this.location.back();
  }

  salvar() {
    this.lancamentoPagarService.salvar(this.lancamentoPagar).subscribe(
      obj => {
        this.lancamentoPagar = obj;
        this.global.mostraMensagem(this.global.info, "Confirmação", 'Registro salvo com sucesso');
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  buscaNaturezaFinanceira(event) {
    console.log(event.query);
    this.naturezaFinananceiraService.getListaFinNaturezaFinanceira(event.query).subscribe(
      obj => {
        this.filtroNaturezaFinanceira = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  buscaDocumentoOrigem(event) {
    this.documentoOrigemService.getListaFinDocumentoOrigem(event.query).subscribe(
      obj => {
        this.filtroDocumentoOrigem = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  buscaFornecedor(event) {
    this.fornecedorService.getListaFornecedor(event.query).subscribe(
      obj => {
        this.filtroFornecedor = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  buscaContaCaixa(event) {
    this.contaCaixaService.getListaContaCaixa(event.query).subscribe(
      obj => {
        this.filtroContaCaixa = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  onSubmit(value) {
    let listaDetalhe: FinParcelaPagar[] = this.lancamentoPagar.listaFinParcelaPagar;
    this.lancamentoPagar = value as FinLancamentoPagar;
    this.lancamentoPagar.listaFinParcelaPagar = listaDetalhe;
    this.salvar();
  }

}
