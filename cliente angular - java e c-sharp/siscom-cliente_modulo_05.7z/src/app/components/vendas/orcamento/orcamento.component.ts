import { VariaveisGlobais } from './../../../classes/variaveis-globais';
import { ConfirmationService } from 'primeng/api';
import { VendaOrcamentoService } from './../../../services/vendas/venda-orcamento.service';
import { VendaOrcamentoCabecalho } from './../../../classes/vendas/venda-orcamento-cabecalho';
import { Component, OnInit } from '@angular/core';
import { ObjectUtils } from '../../../../../node_modules/primeng/components/utils/objectutils';

@Component({
  selector: 'app-orcamento',
  templateUrl: './orcamento.component.html',
  styleUrls: ['./orcamento.component.css']
})
export class OrcamentoComponent implements OnInit {

  listaOrcamento: VendaOrcamentoCabecalho[];
  cols: any[];
  orcamentoSelecionado: VendaOrcamentoCabecalho;
  botoesDesabilitados: boolean = true;

  constructor(private orcamentoService: VendaOrcamentoService,
    private confirmationService: ConfirmationService,
    private global: VariaveisGlobais,
    private objectUtils: ObjectUtils) { }

  ngOnInit() {
    this.global.tituloJanela = "Lista de Orçamentos";
    this.carregaDados();

    this.cols = [
      { field: 'cliente.pessoa.nome', header: 'Cliente' },
      { field: 'codigo', header: 'Código' },
      { field: 'valorTotal', header: 'Total' }
    ];
  }

  resolveFieldData(data, field) {
    return this.objectUtils.resolveFieldData(data, field);
  }

  private carregaDados() {
    this.orcamentoService.getListaVendaOrcamentoCabecalho().subscribe(
      lista => {
        this.listaOrcamento = lista;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  onRowSelect(event) {
    this.botoesDesabilitados = false;
  }

  onRowUnselect(event) {
    this.botoesDesabilitados = true;
  }

  getIdOrcamento() {
    return this.orcamentoSelecionado == null ? null : this.orcamentoSelecionado.id;
  }

  excluir() {
    this.confirmationService.confirm({
      message: 'Excluir o registro selecionado?',
      header: 'Confirmação',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.orcamentoService.excluir(this.orcamentoSelecionado.id).subscribe(
          _ => {
            this.carregaDados();
            this.botoesDesabilitados = true;
            this.global.mostraMensagem(this.global.info, "Confirmação", 'Registro excluído com sucesso');
          },
          error => {
            this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
          }
        );
      },
      reject: () => {
        //this.msgs = [{ severity: 'info', summary: 'Rejected', detail: 'You have rejected' }];
      }
    });
  }
}
