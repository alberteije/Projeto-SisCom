import { VariaveisGlobais } from './../../../classes/variaveis-globais';
import { ConfirmationService } from 'primeng/api';
import { EstoqueContagemService } from './../../../services/estoque/estoque-contagem.service';
import { EstoqueContagemCabecalho } from './../../../classes/estoque/estoque-contagem-cabecalho';
import { Component, OnInit } from '@angular/core';
import { ObjectUtils } from '../../../../../node_modules/primeng/components/utils/objectutils';

@Component({
  selector: 'app-contagem',
  templateUrl: './contagem.component.html',
  styleUrls: ['./contagem.component.css']
})
export class ContagemComponent implements OnInit {

  listaEstoqueContagem: EstoqueContagemCabecalho[];
  cols: any[];
  estoqueContagemSelecionado: EstoqueContagemCabecalho;
  botoesDesabilitados: boolean = true;

  constructor(private estoqueContagemService: EstoqueContagemService,
    private confirmationService: ConfirmationService,
    private global: VariaveisGlobais,
    private objectUtils: ObjectUtils) { }

  ngOnInit() {
    this.global.tituloJanela = "Lista de Contagens";
    this.carregaDados();

    this.cols = [
      { field: 'dataContagem', header: 'Data' },
      { field: 'estoqueAtualizado', header: 'Estoque Atualizado' }
    ];
  }

  resolveFieldData(data, field) {
    return this.objectUtils.resolveFieldData(data, field);
  }

  private carregaDados() {
    this.estoqueContagemService.getListaEstoqueContagemCabecalho().subscribe(
      lista => {
        this.listaEstoqueContagem = lista;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  onRowSelect(event) {
    this.botoesDesabilitados = false;
  }

  onRowUnselect(event) {
    this.botoesDesabilitados = true;
  }

  getIdEstoqueContagem() {
    return this.estoqueContagemSelecionado == null ? null : this.estoqueContagemSelecionado.id;
  }

  excluir() {
    this.confirmationService.confirm({
      message: 'Excluir o registro selecionado?',
      header: 'Confirmação',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.estoqueContagemService.excluir(this.estoqueContagemSelecionado.id).subscribe(
          _ => {
            this.carregaDados();
            this.botoesDesabilitados = true;
            this.global.mostraMensagem(this.global.info, "Confirmação", 'Registro excluído com sucesso');
          },
          error => {
            this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
          }
        );
      },
      reject: () => {
        //this.msgs = [{ severity: 'info', summary: 'Rejected', detail: 'You have rejected' }];
      }
    });
  }

}
