import { Component, OnInit } from '@angular/core';

import { VariaveisGlobais } from './../../../classes/variaveis-globais';
import { EstoqueReajusteService } from './../../../services/estoque/estoque-reajuste.service';
import { EstoqueReajusteCabecalho } from './../../../classes/estoque/estoque-reajuste-cabecalho';

import { ConfirmationService } from 'primeng/api';
import { ObjectUtils } from '../../../../../node_modules/primeng/components/utils/objectutils';

@Component({
  selector: 'app-reajuste',
  templateUrl: './reajuste.component.html',
  styleUrls: ['./reajuste.component.css']
})
export class ReajusteComponent implements OnInit {

  listaEstoqueReajuste: EstoqueReajusteCabecalho[];
  cols: any[];
  estoqueReajusteSelecionado: EstoqueReajusteCabecalho;
  botoesDesabilitados: boolean = true;

  constructor(private estoqueReajusteService: EstoqueReajusteService,
    private confirmationService: ConfirmationService,
    private global: VariaveisGlobais,
    private objectUtils: ObjectUtils) { }

  ngOnInit() {
    this.global.tituloJanela = "Lista de Reajustes";
    this.carregaDados();

    this.cols = [
      { field: 'colaborador.pessoa.nome', header: 'Colaborador' },
      { field: 'dataReajuste', header: 'Data' },
      { field: 'porcentagem', header: 'Porcentagem' },
      { field: 'tipoReajuste', header: 'Tipo' }
    ];
  }

  resolveFieldData(data, field) {
    return this.objectUtils.resolveFieldData(data, field);
  }

  private carregaDados() {
    this.estoqueReajusteService.getListaEstoqueReajusteCabecalho().subscribe(
      lista => {
        this.listaEstoqueReajuste = lista;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  onRowSelect(event) {
    this.botoesDesabilitados = false;
  }

  onRowUnselect(event) {
    this.botoesDesabilitados = true;
  }

  getIdEstoqueReajuste() {
    return this.estoqueReajusteSelecionado == null ? null : this.estoqueReajusteSelecionado.id;
  }

  excluir() {
    this.confirmationService.confirm({
      message: 'Excluir o registro selecionado?',
      header: 'Confirmação',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.estoqueReajusteService.excluir(this.estoqueReajusteSelecionado.id).subscribe(
          _ => {
            this.carregaDados();
            this.botoesDesabilitados = true;
            this.global.mostraMensagem(this.global.info, "Confirmação", 'Registro excluído com sucesso');
          },
          error => {
            this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
          }
        );
      },
      reject: () => {
        //this.msgs = [{ severity: 'info', summary: 'Rejected', detail: 'You have rejected' }];
      }
    });
  }
}
