import { EstoqueReajusteDetalhe } from './../../../../classes/estoque/estoque-reajuste-detalhe';
import { VariaveisGlobais } from './../../../../classes/variaveis-globais';
import { ProdutoService } from './../../../../services/cadastros/produto.service';
import { ColaboradorService } from './../../../../services/cadastros/colaborador.service';
import { EstoqueReajusteService } from './../../../../services/estoque/estoque-reajuste.service';
import { Produto } from './../../../../classes/cadastros/produto';
import { Colaborador } from './../../../../classes/cadastros/colaborador';
import { Component, OnInit } from '@angular/core';
import { SelectItem } from '../../../../../../node_modules/primeng/api';
import { EstoqueReajusteCabecalho } from '../../../../classes/estoque/estoque-reajuste-cabecalho';
import { FormGroup, FormBuilder, FormControl, Validators } from '../../../../../../node_modules/@angular/forms';
import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { Location } from '../../../../../../node_modules/@angular/common';
import { ObjectUtils } from '../../../../../../node_modules/primeng/components/utils/objectutils';

@Component({
  selector: 'app-reajuste-detalhe',
  templateUrl: './reajuste-detalhe.component.html',
  styleUrls: ['./reajuste-detalhe.component.css']
})
export class ReajusteDetalheComponent implements OnInit {

  opcoesTipoReajuste: SelectItem[];

  estoqueReajuste: EstoqueReajusteCabecalho;
  filtroColaborador: Colaborador[];
  userform: FormGroup;

  cols: any[];
  display: boolean = false;
  filtroProduto: Produto[];
  produto: Produto;

  constructor(private estoqueReajusteService: EstoqueReajusteService,
    private colaboradorService: ColaboradorService,
    private produtoService: ProdutoService,
    private route: ActivatedRoute,
    private location: Location,
    private router: Router,
    private global: VariaveisGlobais,
    private fb: FormBuilder,
    private objectUtils: ObjectUtils) { }

  ngOnInit() {
    this.opcoesTipoReajuste = [
      { label: 'Aumentar', value: 'A' },
      { label: 'Diminuir', value: 'D' },
    ];

    this.userform = this.fb.group({
      'id': new FormControl(''),
      'colaborador': new FormControl('', Validators.required),
      'porcentagem': new FormControl('', Validators.required),
      'dataReajuste': new FormControl('', Validators.required),
      'tipoReajuste': new FormControl('', Validators.required)
    });

    this.cols = [
      { field: 'produto.nome', header: 'Produto' }
    ];

    this.global.tituloJanela = "Detalhe Reajuste";
    this.estoqueReajuste = new EstoqueReajusteCabecalho();

    if (this.router.url !== '/estoque-reajuste/novo') {
      let id = this.route.snapshot.paramMap.get('id');
      this.estoqueReajusteService.getEstoqueReajusteCabecalho(parseInt(id, 0)).subscribe(
        obj => {
          this.estoqueReajuste = obj;
          this.userform.patchValue(this.estoqueReajuste);
        },
        error => {
          this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
        }
      );
    }
  }

  resolveFieldData(data, field) {
    return this.objectUtils.resolveFieldData(data, field);
  }

  retornar() {
    this.location.back();
  }

  salvar() {
    this.estoqueReajusteService.salvar(this.estoqueReajuste).subscribe(
      obj => {
        this.estoqueReajuste = obj;
        this.global.mostraMensagem(this.global.info, "Confirmação", 'Registro salvo com sucesso');
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  buscaColaborador(event) {
    this.colaboradorService.getListaColaboradores(event.query).subscribe(
      obj => {
        this.filtroColaborador = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  buscaProduto(event) {
    this.produtoService.getListaProduto(event.query).subscribe(
      obj => {
        this.filtroProduto = obj;
      },
      error => {
        this.global.mostraMensagem(this.global.error, "Ocorreu um erro", this.global.trataErro(error));
      }
    );
  }

  onSubmit(value) {
    let listaDetalhe: EstoqueReajusteDetalhe[] = this.estoqueReajuste.listaEstoqueReajusteDetalhe;
    this.estoqueReajuste = value as EstoqueReajusteCabecalho;
    this.estoqueReajuste.listaEstoqueReajusteDetalhe = listaDetalhe;
    this.salvar();
  }

  novoDetalhe() {
    this.display = true;
  }

  cancelaInclusao() {
    this.display = false;
  }

  incluirProduto() {
    let detalhe: EstoqueReajusteDetalhe = new EstoqueReajusteDetalhe();
    detalhe.produto = this.produto;
    this.estoqueReajuste.listaEstoqueReajusteDetalhe.push(detalhe);

    this.display = false;
  }

}
