import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReajusteDetalheComponent } from './reajuste-detalhe.component';

describe('ReajusteDetalheComponent', () => {
  let component: ReajusteDetalheComponent;
  let fixture: ComponentFixture<ReajusteDetalheComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReajusteDetalheComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReajusteDetalheComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
