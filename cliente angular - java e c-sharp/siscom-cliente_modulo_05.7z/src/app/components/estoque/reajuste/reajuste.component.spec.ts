import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReajusteComponent } from './reajuste.component';

describe('ReajusteComponent', () => {
  let component: ReajusteComponent;
  let fixture: ComponentFixture<ReajusteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReajusteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReajusteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
