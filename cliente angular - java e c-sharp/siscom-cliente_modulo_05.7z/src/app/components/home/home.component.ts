import { Component, OnInit } from '@angular/core';
import { VariaveisGlobais } from '../../classes/variaveis-globais';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private global: VariaveisGlobais) { }

  ngOnInit() {
    this.global.tituloJanela = 'T2Ti.com - SisCom';
  }

}
