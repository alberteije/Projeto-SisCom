package com.t2ti.siscom.services.financeiro;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.t2ti.siscom.model.financeiro.FinTipoPagamento;
import com.t2ti.siscom.repository.financeiro.FinTipoPagamentoRepository;

@Service
public class FinTipoPagamentoService {

	@Autowired
	private FinTipoPagamentoRepository repository;
	
	public List<FinTipoPagamento> listaTodos() {
		return repository.findAll();
	}
	
	public List<FinTipoPagamento> listaTodos(String nome) {
		return repository.findFirst10ByDescricaoContaining(nome);
	}
	
	public FinTipoPagamento buscaPorId(Integer id) {
		return repository.findById(id).get();
	}
	
	public FinTipoPagamento salvaObjeto(FinTipoPagamento finTipoPagamento) {
		return repository.save(finTipoPagamento);
	}
	
	public void excluirObjeto(Integer id) {
		FinTipoPagamento finTipoPagamento = new FinTipoPagamento();
		finTipoPagamento.setId(id);
		repository.delete(finTipoPagamento);
	}
	
}
