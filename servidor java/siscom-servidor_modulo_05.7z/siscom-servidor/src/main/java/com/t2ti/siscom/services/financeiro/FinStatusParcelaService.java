package com.t2ti.siscom.services.financeiro;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.t2ti.siscom.model.financeiro.FinStatusParcela;
import com.t2ti.siscom.repository.financeiro.FinStatusParcelaRepository;

@Service
public class FinStatusParcelaService {

	@Autowired
	private FinStatusParcelaRepository repository;
	
	public List<FinStatusParcela> listaTodos() {
		return repository.findAll();
	}
	
	public List<FinStatusParcela> listaTodos(String nome) {
		return repository.findFirst10ByDescricaoContaining(nome);
	}
	
	public FinStatusParcela buscaPorId(Integer id) {
		return repository.findById(id).get();
	}
	
	public FinStatusParcela salvaObjeto(FinStatusParcela finStatusParcela) {
		return repository.save(finStatusParcela);
	}
	
	public void excluirObjeto(Integer id) {
		FinStatusParcela finStatusParcela = new FinStatusParcela();
		finStatusParcela.setId(id);
		repository.delete(finStatusParcela);
	}
	
}
