package com.t2ti.siscom.services.vendas;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.t2ti.siscom.model.vendas.TipoNotaFiscal;
import com.t2ti.siscom.repository.vendas.TipoNotaFiscalRepository;

@Service
public class TipoNotaFiscalService {

	@Autowired
	private TipoNotaFiscalRepository repository;
	
	public List<TipoNotaFiscal> listaTodos() {
		return repository.findAll();
	}
	
	public List<TipoNotaFiscal> listaTodos(String nome) {
		return repository.findFirst10ByNomeContaining(nome);
	}
	
	public TipoNotaFiscal buscaPorId(Integer id) {
		return repository.findById(id).get();
	}
	
	public TipoNotaFiscal salvaObjeto(TipoNotaFiscal tipoNotaFiscal) {
		return repository.save(tipoNotaFiscal);
	}
	
	public void excluirObjeto(Integer id) {
		TipoNotaFiscal tipoNotaFiscal = new TipoNotaFiscal();
		tipoNotaFiscal.setId(id);
		repository.delete(tipoNotaFiscal);
	}
	
}
