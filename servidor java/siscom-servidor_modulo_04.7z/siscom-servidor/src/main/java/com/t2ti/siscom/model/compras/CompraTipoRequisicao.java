package com.t2ti.siscom.model.compras;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the compra_tipo_requisicao database table.
 * 
 */
@Entity
@Table(name="compra_tipo_requisicao")
@NamedQuery(name="CompraTipoRequisicao.findAll", query="SELECT c FROM CompraTipoRequisicao c")
public class CompraTipoRequisicao implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private Integer id;

	private String codigo;

	@Lob
	private String descricao;

	private String nome;

	public CompraTipoRequisicao() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCodigo() {
		return this.codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return this.descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}