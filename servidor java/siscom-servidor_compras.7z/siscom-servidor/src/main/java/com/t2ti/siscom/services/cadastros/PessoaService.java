package com.t2ti.siscom.services.cadastros;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.t2ti.siscom.model.cadastros.Pessoa;
import com.t2ti.siscom.repository.cadastros.PessoaRepository;

@Service
public class PessoaService {

	@Autowired
	private PessoaRepository repository;
	
	public List<Pessoa> listaTodos() {
		return repository.findAll();
	}
	
	public List<Pessoa> listaTodos(String nome) {
		return repository.findFirst10ByNomeContaining(nome);
	}
	
	public Pessoa buscaPorId(Integer id) {
		return repository.findById(id).get();
	}
	
	public Pessoa salvaObjeto(Pessoa pessoa) {
		return repository.save(pessoa);
	}
	
	public void excluirObjeto(Integer id) {
		Pessoa pessoa = new Pessoa();
		pessoa.setId(id);
		repository.delete(pessoa);
	}
	
}
