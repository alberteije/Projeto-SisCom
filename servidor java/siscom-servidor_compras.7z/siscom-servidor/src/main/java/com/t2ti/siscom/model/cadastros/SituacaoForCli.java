package com.t2ti.siscom.model.cadastros;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the situacao_for_cli database table.
 * 
 */
@Entity
@Table(name="situacao_for_cli")
@NamedQuery(name="SituacaoForCli.findAll", query="SELECT s FROM SituacaoForCli s")
public class SituacaoForCli implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	@Lob
	private String descricao;

	private String nome;

	public SituacaoForCli() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescricao() {
		return this.descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}